# Vantera Roleplay

Svensk FiveM-community portal:

- Discord-inloggning (Supabase Auth) med **behörigheter från riktiga Discord-roller**
- Ansökningsformulär som staff redigerar på sajten, med Discord-notiser och DM-besked
- Staff-panel: ansökningar, dokumentation, medlemmar, formulär, regler & prislista, behörigheter, loggar
- Regler och information som redigeras direkt på hemsidan

Se **SETUP.md** för installation (Supabase + Netlify, gratis).

| Sökväg | Beskrivning |
|--------|-------------|
| `/` | Startsida |
| `/ansokningar` | Formulär |
| `/information` | Regler, köpvillkor, prislista |
| `/portal` | Min portal (roller, ansökningar, svar från staff) |
| `/staff` | Staff-panel (filtreras per Discord-roll) |

Kod: `src/` (sajten), `supabase/schema.sql` (databas), `supabase/functions/` (Edge Functions).
Standardformulär och -regler ligger i `src/lib/default-forms.ts` och `src/lib/default-pages.ts`; kör `npm run gen:schema` för att bygga om `supabase/schema.sql` efter att du ändrat dem.
