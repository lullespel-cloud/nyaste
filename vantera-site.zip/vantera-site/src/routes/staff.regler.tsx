import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { Field, inputCls } from "@/components/fields";
import { RichText } from "@/lib/markdown";
import { useAuth } from "@/lib/auth";
import { supabase, type PageRow } from "@/lib/supabase";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/staff/regler")({
  head: () => ({ meta: [{ title: `Regler & info – ${SITE_NAME}` }] }),
  component: RulesAdmin,
});

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/å|ä/g, "a")
    .replace(/ö/g, "o")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);

const HELP = `## Rubrik
1. Numrerad regel
- Punktlista
**fet text**
> Ruta med viktig information
Tabell (första raden = rubrikrad, kolumner med |):
Föremål | Pris
Kriminell roll | 150 kr`;

function RulesAdmin() {
  const { user, canEdit, loading } = useAuth();
  const [pages, setPages] = useState<PageRow[]>([]);
  const [editing, setEditing] = useState<PageRow | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from("pages").select("*").order("category").order("sort", { ascending: true });
    if (error) setMsg("Kunde inte hämta sidor: " + error.message);
    else setPages((data as PageRow[]) ?? []);
  }, []);

  useEffect(() => {
    if (user && canEdit) void load();
  }, [user, canEdit, load]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }
  if (!user || !canEdit) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess text="Bara Ägare, Delägare, Head Admin och Admin kan redigera regler och prislista." />
      </Layout>
    );
  }

  const patch = (p: Partial<PageRow>) => setEditing((e) => (e ? { ...e, ...p } : e));

  async function save() {
    if (!editing) return;
    const slug = isNew ? slugify(editing.slug || editing.title) : editing.slug;
    if (!slug || !editing.title.trim()) {
      setMsg("Sidan behöver en titel.");
      return;
    }
    setSaving(true);
    const { updated_at: _ignored, ...row } = editing;
    const { error } = await supabase.from("pages").upsert({ ...row, slug }, { onConflict: "category,slug" });
    setSaving(false);
    if (error) {
      setMsg("Kunde inte spara: " + error.message);
      return;
    }
    setMsg("Sparat! Ändringen syns direkt på sajten.");
    setEditing(null);
    void load();
  }

  async function remove(p: PageRow) {
    if (!window.confirm(`Ta bort "${p.title}"?`)) return;
    const { error } = await supabase.from("pages").delete().eq("category", p.category).eq("slug", p.slug);
    if (error) setMsg("Kunde inte ta bort: " + error.message);
    else {
      setEditing(null);
      void load();
    }
  }

  return (
    <Layout>
      <PageHeader eyebrow="Staff" title="Regler & information" intro="Redigera reglerna, köpvillkor och prislistan. Ändringar sparas i databasen och syns direkt på den publika sidan." />
      <StaffNav />
      {msg && <div className="mx-auto mt-4 max-w-4xl rounded-md border border-violet-500/40 bg-violet-500/10 px-4 py-3 text-sm">{msg}</div>}

      {!editing ? (
        <div className="mx-auto mt-6 max-w-4xl space-y-3">
          <button
            onClick={() => {
              setEditing({ category: "regler", slug: "", title: "", meta: "Regler", body: "", sort: 100, staff_only: false });
              setIsNew(true);
              setMsg(null);
            }}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
          >
            <Plus className="h-4 w-4" /> Ny sida
          </button>
          {pages.map((p) => (
            <button
              key={`${p.category}/${p.slug}`}
              onClick={() => {
                setEditing({ ...p });
                setIsNew(false);
                setMsg(null);
              }}
              className="glass flex w-full items-center justify-between gap-3 rounded-lg p-4 text-left hover:bg-accent/50"
            >
              <div>
                <div className="font-semibold">{p.title}</div>
                <div className="text-xs text-muted-foreground">
                  {p.category === "regler" ? "Regler" : "Information"}
                  {p.staff_only && " · endast staff"}
                  {p.updated_at && <> · uppdaterad {new Date(p.updated_at).toLocaleDateString("sv-SE")}</>}
                </div>
              </div>
              <span className="text-sm text-muted-foreground">Redigera →</span>
            </button>
          ))}
          {pages.length === 0 && <p className="text-sm text-muted-foreground">Inga sidor. Kör supabase/schema.sql så läggs standardreglerna in.</p>}
        </div>
      ) : (
        <div className="mx-auto mt-6 max-w-6xl space-y-5">
          <div className="glass space-y-4 rounded-lg p-6">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Titel" required>
                <input className={inputCls} value={editing.title} onChange={(e) => patch({ title: e.target.value })} />
              </Field>
              <Field label="Kategori">
                <select className={inputCls} disabled={!isNew} value={editing.category} onChange={(e) => patch({ category: e.target.value as PageRow["category"] })}>
                  <option value="regler">Regler</option>
                  <option value="information">Information</option>
                </select>
              </Field>
              <Field label="Sortering (lägst först)">
                <input type="number" className={inputCls} value={editing.sort} onChange={(e) => patch({ sort: Number(e.target.value) })} />
              </Field>
            </div>
            <Field label="Undertext (visas under rubriken)">
              <input className={inputCls} value={editing.meta} onChange={(e) => patch({ meta: e.target.value })} />
            </Field>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={editing.staff_only} onChange={(e) => patch({ staff_only: e.target.checked })} /> Endast synlig för staff (t.ex. staffregler)
            </label>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <div className="glass rounded-lg p-4">
              <div className="mb-2 flex items-center justify-between text-sm font-medium">
                Text
                <details className="text-xs font-normal text-muted-foreground">
                  <summary className="cursor-pointer">Formatering</summary>
                  <pre className="mt-2 whitespace-pre-wrap rounded bg-secondary p-2">{HELP}</pre>
                </details>
              </div>
              <textarea className={`${inputCls} min-h-[420px] font-mono`} value={editing.body} onChange={(e) => patch({ body: e.target.value })} />
            </div>
            <div className="glass rounded-lg p-6">
              <div className="mb-3 text-sm font-medium text-muted-foreground">Förhandsvisning</div>
              <RichText text={editing.body} />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button onClick={() => void save()} disabled={saving} className="rounded-md bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50">
              {saving ? "Sparar…" : "Spara"}
            </button>
            <button onClick={() => setEditing(null)} className="rounded-md border px-5 py-2.5 text-sm font-semibold hover:bg-accent">
              Avbryt
            </button>
            {!isNew && (
              <button onClick={() => void remove(editing)} className="ml-auto rounded-md border border-red-500/40 px-4 py-2.5 text-sm font-semibold text-red-300 hover:bg-red-500/10">
                Ta bort sida
              </button>
            )}
          </div>
        </div>
      )}
    </Layout>
  );
}
