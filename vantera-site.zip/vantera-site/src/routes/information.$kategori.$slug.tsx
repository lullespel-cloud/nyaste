import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { RichText } from "@/lib/markdown";
import { informationCategories, usePages } from "@/lib/content";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/information/$kategori/$slug")({
  loader: ({ params }) => {
    if (!(params.kategori in informationCategories)) throw notFound();
    return null;
  },
  head: () => ({ meta: [{ title: `Regler & information – ${SITE_NAME}` }] }),
  component: Page,
});

function Page() {
  const { kategori, slug } = Route.useParams();
  const cat = informationCategories[kategori as keyof typeof informationCategories];
  const { pages, loading } = usePages(kategori as "regler" | "information");
  const page = pages.find((p) => p.slug === slug);

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <Link to="/information/$kategori" params={{ kategori }} className="text-sm text-muted-foreground">
          ← {cat.label}
        </Link>
        {loading ? (
          <p className="mt-10 text-muted-foreground">Laddar…</p>
        ) : !page ? (
          <div className="mt-10">
            <h1 className="text-glow text-3xl font-bold">Sidan hittades inte</h1>
            <p className="mt-3 text-sm text-muted-foreground">Sidan finns inte, eller så kräver den att du är inloggad som staff.</p>
          </div>
        ) : (
          <>
            <h1 className="text-glow mt-10 text-3xl font-bold">{page.title}</h1>
            <span className="mt-3 inline-block rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{cat.label}</span>
            <p className="mt-4 border-b pb-6 text-sm text-muted-foreground">
              {page.meta}
              {page.updated_at && <> · Uppdaterad {new Date(page.updated_at).toLocaleDateString("sv-SE")}</>}
            </p>
            <article className="glass mt-8 rounded-lg p-8 md:p-12">
              <RichText text={page.body} />
            </article>
          </>
        )}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <Link to="/information/$kategori" params={{ kategori }}>
            ← Tillbaka till {cat.label.toLowerCase()}
          </Link>
        </div>
      </div>
    </Layout>
  );
}
