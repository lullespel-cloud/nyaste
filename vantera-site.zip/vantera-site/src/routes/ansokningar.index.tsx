import { createFileRoute, Link } from "@tanstack/react-router";
import { MessageSquare } from "lucide-react";
import { Layout, PageHeader, LoggedInBanner, LoginPrompt } from "@/components/Layout";
import { SITE_NAME } from "@/lib/site";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/ansokningar/")({
  head: () => ({
    meta: [
      { title: `Ansökningar – ${SITE_NAME}` },
      { name: "description", content: "Välj ansökningar eller serversupport för att se alla formulär." },
    ],
  }),
  component: Page,
});

const cats = [
  { k: "ansokningar", title: "Ansökningar", desc: "Medlemskap, kriminell, servervakt, staff, medlemskapsansvarig med mera." },
  { k: "serversupport", title: "Serversupport", desc: "Banöverklagan och privata ärenden med behörig staff." },
];

function Page() {
  const { user } = useAuth();
  return (
    <Layout>
      <PageHeader
        eyebrow="Ansökningar"
        title="Välj kategori"
        intro="Välj ansökningar eller serversupport för att se alla formulär. Du behöver vara inloggad med Discord för att skicka in."
      />
      {user ? <LoggedInBanner /> : <LoginPrompt />}
      <div className="mx-auto mt-12 grid max-w-4xl gap-5 md:grid-cols-2">
        {cats.map((c) => (
          <Link
            key={c.k}
            to="/ansokningar/$kategori"
            params={{ kategori: c.k }}
            className="glass flex gap-4 rounded-lg p-5 transition-transform hover:-translate-y-1"
          >
            <div className="h-fit rounded-md bg-secondary p-2.5">
              <MessageSquare className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{c.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{c.desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </Layout>
  );
}
