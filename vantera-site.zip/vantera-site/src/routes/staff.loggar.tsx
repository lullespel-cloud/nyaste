import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { useAuth } from "@/lib/auth";
import { supabase, type AuditRow } from "@/lib/supabase";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/staff/loggar")({
  head: () => ({ meta: [{ title: `Loggar – ${SITE_NAME}` }] }),
  component: AuditPage,
});

const ACTIONS: Record<string, string> = {
  ansokan_approved: "Godkände ansökan",
  ansokan_denied: "Nekade ansökan",
  ansokan_closed: "Stängde ansökan",
  ansokan_pending: "Återställde ansökan till väntande",
  forms_insert: "Skapade formulär",
  forms_update: "Ändrade formulär",
  forms_delete: "Tog bort formulär",
  pages_insert: "Skapade sida",
  pages_update: "Ändrade sida",
  pages_delete: "Tog bort sida",
};

function AuditPage() {
  const { user, canEdit, loading } = useAuth();
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user || !canEdit) return;
    supabase
      .from("audit_log")
      .select("*, profiles(discord_username, display_name)")
      .order("created_at", { ascending: false })
      .limit(200)
      .then(({ data, error: e }) => {
        if (e) setError(e.message);
        else setRows((data as unknown as AuditRow[]) ?? []);
      });
  }, [user, canEdit]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }
  if (!user || !canEdit) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess text="Bara Ägare, Delägare, Head Admin och Admin kan se loggarna." />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader eyebrow="Staff" title="Loggar" intro="Vem som godkänt/nekat ansökningar och ändrat formulär, regler och prislista." />
      <StaffNav />
      <div className="mx-auto mt-6 max-w-4xl space-y-2">
        {error && <p className="text-sm text-red-300">{error}</p>}
        {rows.map((r) => (
          <div key={r.id} className="glass flex flex-wrap items-center justify-between gap-2 rounded-lg px-4 py-3 text-sm">
            <div>
              <span className="font-semibold">{r.profiles?.display_name || r.profiles?.discord_username || "System"}</span>{" "}
              {ACTIONS[r.action] ?? r.action}
              {r.target && <span className="text-muted-foreground"> · {String((r.detail as Record<string, unknown> | null)?.["titel"] ?? r.target)}</span>}
            </div>
            <div className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("sv-SE")}</div>
          </div>
        ))}
        {rows.length === 0 && !error && <p className="text-center text-sm text-muted-foreground">Inga händelser ännu.</p>}
      </div>
    </Layout>
  );
}
