import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { useAuth } from "@/lib/auth";
import { supabase, type FormRow } from "@/lib/supabase";
import { CONTENT_EDITORS, ROLE_LABELS, STAFF_LEVEL } from "@/lib/permissions";
import { DEFAULT_FORMS } from "@/lib/default-forms";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/staff/behorigheter")({
  head: () => ({ meta: [{ title: `Behörigheter – ${SITE_NAME}` }] }),
  component: PermissionsPage,
});

function PermissionsPage() {
  const { user, isStaff, loading, profile } = useAuth();
  const [forms, setForms] = useState<FormRow[]>([]);

  useEffect(() => {
    if (!user || !isStaff) return;
    supabase
      .from("forms")
      .select("*")
      .order("sort")
      .then(({ data }) => setForms(((data as FormRow[] | null) ?? []).length ? (data as FormRow[]) : (DEFAULT_FORMS as FormRow[])));
  }, [user, isStaff]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }
  if (!user || !isStaff) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess />
      </Layout>
    );
  }

  const myRoles = (profile?.roles ?? []).filter((r) => ROLE_LABELS[r]);

  return (
    <Layout>
      <PageHeader eyebrow="Staff" title="Behörigheter" intro="Rollerna hämtas automatiskt från Discord. Vilken Discord-roll som ger vilken sajtroll sätts i Supabase (hemligheterna ROLE_MAP / ROLE_MAP_EXTRA, se SETUP.md)." />
      <StaffNav />
      <div className="mx-auto mt-6 max-w-4xl space-y-4">
        <div className="glass rounded-lg p-4 text-sm">
          Dina roller: {myRoles.length ? myRoles.map((r) => ROLE_LABELS[r]).join(", ") : "inga"}
        </div>
        <div className="glass overflow-x-auto rounded-lg">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-xs uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-3">Roll</th>
                <th className="px-4 py-3">Hanterar ansökningar</th>
                <th className="px-4 py-3">Dokumentation</th>
                <th className="px-4 py-3">Redigerar regler/formulär</th>
              </tr>
            </thead>
            <tbody>
              {STAFF_LEVEL.map((role) => {
                const editor = (CONTENT_EDITORS as string[]).includes(role);
                const handles = editor ? ["Alla"] : forms.filter((f) => f.handler_roles.includes(role)).map((f) => f.title);
                return (
                  <tr key={role} className="border-b last:border-0 align-top">
                    <td className="px-4 py-3 font-semibold">{ROLE_LABELS[role]}</td>
                    <td className="px-4 py-3 text-muted-foreground">{handles.length ? handles.join(", ") : "–"}</td>
                    <td className="px-4 py-3">Ja</td>
                    <td className="px-4 py-3">{editor ? "Ja" : "Nej"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
}
