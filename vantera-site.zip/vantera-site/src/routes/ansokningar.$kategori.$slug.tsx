import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Layout, PageHeader, LoginPrompt } from "@/components/Layout";
import { Field, inputCls } from "@/components/fields";
import { applicationCategories, useForms } from "@/lib/content";
import { SITE_NAME } from "@/lib/site";
import { useAuth } from "@/lib/auth";
import { supabase, type Answer } from "@/lib/supabase";

export const Route = createFileRoute("/ansokningar/$kategori/$slug")({
  loader: ({ params }) => {
    if (!(params.kategori in applicationCategories)) throw notFound();
    return null;
  },
  head: () => ({ meta: [{ title: `Formulär – ${SITE_NAME}` }] }),
  component: FormPage,
});

function FormPage() {
  const { kategori, slug } = Route.useParams();
  const cat = applicationCategories[kategori as keyof typeof applicationCategories];
  const { forms, loading: formsLoading } = useForms();
  const form = forms.find((f) => f.slug === slug && f.category === kategori && f.enabled);
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const back = <Link to="/ansokningar/$kategori" params={{ kategori }}>← Tillbaka</Link>;

  if (formsLoading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!form) {
    return (
      <Layout>
        <PageHeader eyebrow={cat.label} title="Formuläret finns inte" intro="Det kan ha tagits bort eller stängts." back={back} />
      </Layout>
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !form) return;
    setSubmitting(true);
    setError(null);

    // Svaren sparas med frågan (label) så de går att läsa även om formuläret ändras senare
    const answers: Answer[] = form.fields
      .map((f) => ({ id: f.id, label: f.label, value: (values[f.id] ?? "").trim() }))
      .filter((a) => a.value !== "");

    const { data, error: insertError } = await supabase
      .from("applications")
      .insert({
        user_id: user.id,
        category: cat.label,
        form_slug: form.slug,
        title: form.title,
        data: answers,
        status: "pending",
      })
      .select("id")
      .single();

    setSubmitting(false);
    if (insertError || !data) {
      setError(insertError?.message ?? "Kunde inte skicka ansökan.");
      return;
    }

    // Meddela staff i Discord. Misslyckas det är ansökan ändå sparad.
    void supabase.functions.invoke("application-event", { body: { type: "created", application_id: data.id } }).catch(() => {});

    setDone(true);
    setTimeout(() => navigate({ to: "/portal" }), 1500);
  }

  if (done) {
    return (
      <Layout>
        <PageHeader eyebrow={cat.label} title="Skickat!" intro="Din ansökan har sparats. Du skickas till Min portal där du ser beskedet." />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader eyebrow={cat.label} title={form.title} intro={form.description} back={back} />

      {!loading && !user && <LoginPrompt />}

      {user && (
        <form onSubmit={handleSubmit} className="glass mx-auto mt-10 max-w-2xl space-y-6 rounded-lg p-6">
          <div className="rounded-md bg-secondary/50 px-4 py-3 text-sm">
            Skickas som <strong>{profile?.discord_username || user.user_metadata?.preferred_username || user.email}</strong>
          </div>

          {profile?.in_guild === false && (
            <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-100">
              Du verkar inte vara med i vår Discord-server. Gå med först så att staff kan nå dig med beskedet.
            </div>
          )}

          {form.fields.map((f) => (
            <Field key={f.id} label={f.label} required={f.required} help={f.help}>
              {f.type === "textarea" ? (
                <textarea
                  required={f.required}
                  rows={4}
                  placeholder={f.placeholder}
                  className={inputCls}
                  value={values[f.id] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
                />
              ) : f.type === "select" ? (
                <select
                  required={f.required}
                  className={inputCls}
                  value={values[f.id] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
                >
                  <option value="">Välj…</option>
                  {(f.options ?? []).map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type={f.type === "number" ? "number" : "text"}
                  required={f.required}
                  placeholder={f.placeholder}
                  className={inputCls}
                  value={values[f.id] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
                />
              )}
            </Field>
          ))}

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-md bg-primary px-5 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            {submitting ? "Skickar…" : "Skicka in"}
          </button>
        </form>
      )}
    </Layout>
  );
}
