import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MessageCircle } from "lucide-react";
import { Layout } from "@/components/Layout";
import { SITE_NAME, DISCORD_URL } from "@/lib/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${SITE_NAME} – Svensk FiveM-server` },
      { name: "description", content: "Vantera Roleplay är en svensk FiveM-server. Läs reglerna och ansök om medlemskap." },
      { property: "og:title", content: `${SITE_NAME} – Svensk FiveM-server` },
      { property: "og:description", content: "Läs reglerna och ansök om medlemskap för att spela med oss." },
    ],
  }),
  component: Index,
});

const cards = [
  { to: "/information/$kategori", params: { kategori: "regler" }, title: "Serverregler", desc: "Läs vad som gäller i spelet och på Discord." },
  { to: "/ansokningar", title: "Ansökningar", desc: "Hitta ett formulär eller följ ett ärende." },
  { to: "/information", title: "Information", desc: "Praktisk information och uppdateringar från servern." },
] as const;

function Index() {
  return (
    <Layout>
      <section className="flex min-h-[60vh] flex-col justify-center">
        <h1 className="text-glow font-display text-6xl leading-none md:text-8xl">{SITE_NAME}</h1>
        <p className="mt-6 max-w-md text-lg">En svensk FiveM-server. Läs reglerna och ansök om medlemskap för att spela med oss.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/ansokningar" className="rounded-md bg-primary px-5 py-3 text-sm font-bold text-primary-foreground">Till ansökningarna</Link>
          <a href={DISCORD_URL} className="glass flex items-center gap-2 rounded-md px-5 py-3 text-sm font-bold">
            <MessageCircle className="h-4 w-4" /> Gå med i Discord <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </section>
      <section className="glass mt-10 grid divide-y rounded-lg md:grid-cols-3 md:divide-x md:divide-y-0">
        {cards.map((c) => (
          <Link key={c.title} to={c.to} {...("params" in c ? { params: c.params } : {})} className="p-6 transition-colors hover:bg-accent">
            <h3 className="font-bold">{c.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{c.desc}</p>
          </Link>
        ))}
      </section>
    </Layout>
  );
}
