import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { FileText, RefreshCw, Shield } from "lucide-react";
import { Avatar, Layout, PageHeader, LoginPrompt } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { supabase, type Application } from "@/lib/supabase";
import { statusClass, statusLabel } from "@/lib/notifications";
import { ROLE_LABELS } from "@/lib/permissions";
import { SITE_NAME, DISCORD_URL } from "@/lib/site";

export const Route = createFileRoute("/portal")({
  head: () => ({ meta: [{ title: `Min portal – ${SITE_NAME}` }] }),
  component: PortalPage,
});

function PortalPage() {
  const { user, profile, loading, isStaff, syncing, syncError, syncRoles, signOut } = useAuth();
  const [apps, setApps] = useState<Application[]>([]);
  const [hash, setHash] = useState("");

  useEffect(() => {
    if (!user) return;
    supabase
      .from("applications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => setApps((data as Application[]) ?? []));
  }, [user]);

  useEffect(() => {
    const read = () => setHash(window.location.hash.replace("#", ""));
    read();
    window.addEventListener("hashchange", read);
    return () => window.removeEventListener("hashchange", read);
  }, []);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <PageHeader eyebrow="Min portal" title="Logga in" intro="Logga in med Discord för att se din portal, dina ansökningar och beskeden från staff." />
        <LoginPrompt />
      </Layout>
    );
  }

  const displayName = profile?.display_name || profile?.discord_username || user.user_metadata?.preferred_username || "Användare";
  const avatar = profile?.avatar_url || user.user_metadata?.avatar_url;
  const roles = (profile?.roles ?? []).filter((r) => ROLE_LABELS[r]);

  return (
    <Layout>
      <PageHeader eyebrow="Min portal" title="Översikt" intro="Allt som rör ditt konto på Vantera, samlat på ett ställe." />

      <div className="mx-auto mt-10 max-w-3xl space-y-6">
        <div className="glass rounded-lg p-5">
          <div className="flex flex-wrap items-center gap-4">
            <Avatar src={avatar} name={displayName} className="h-14 w-14 text-xl" />
            <div className="min-w-0 flex-1">
              <h2 className="truncate text-xl font-bold">{displayName}</h2>
              <p className="text-sm text-muted-foreground">
                {profile?.discord_username && <>@{profile.discord_username} · </>}
                Status: {profile?.status || "Medlem"}
              </p>
            </div>
            <button
              onClick={() => void syncRoles()}
              disabled={syncing}
              className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm font-semibold hover:bg-accent disabled:opacity-50"
              title="Hämta dina roller från Discord igen"
            >
              <RefreshCw className={`h-4 w-4 ${syncing ? "animate-spin" : ""}`} /> Uppdatera roller
            </button>
          </div>

          <div className="mt-4 border-t pt-4">
            <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Dina roller från Discord</div>
            <div className="mt-2 flex flex-wrap gap-2">
              {roles.length === 0 ? (
                <span className="text-sm text-muted-foreground">Inga roller hittades ännu.</span>
              ) : (
                roles.map((r) => (
                  <span key={r} className="rounded-full border border-violet-500/40 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-200">
                    {ROLE_LABELS[r]}
                  </span>
                ))
              )}
            </div>
            {profile?.in_guild === false && (
              <p className="mt-3 text-sm text-amber-200">
                Du är inte med i vår Discord-server. <a className="underline" href={DISCORD_URL}>Gå med här</a> och tryck sedan på Uppdatera roller.
              </p>
            )}
            {syncError && <p className="mt-3 text-sm text-red-300">Kunde inte hämta rollerna: {syncError}</p>}
            {profile?.roles_synced_at && (
              <p className="mt-3 text-xs text-muted-foreground">Senast uppdaterad {new Date(profile.roles_synced_at).toLocaleString("sv-SE")}</p>
            )}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Link to="/ansokningar" className="glass flex gap-3 rounded-lg p-4 hover:bg-accent/50">
            <FileText className="h-5 w-5 shrink-0" />
            <div>
              <div className="font-semibold">Skicka ny ansökan</div>
              <div className="text-sm text-muted-foreground">{apps.length === 0 ? "Du har inga ansökningar ännu" : `${apps.length} skickade`}</div>
            </div>
          </Link>
          {isStaff && (
            <Link to="/staff" className="glass flex gap-3 rounded-lg p-4 hover:bg-accent/50">
              <Shield className="h-5 w-5 shrink-0" />
              <div>
                <div className="font-semibold">Staff-panel</div>
                <div className="text-sm text-muted-foreground">Hantera inkomna ärenden</div>
              </div>
            </Link>
          )}
        </div>

        <div className="glass rounded-lg p-5">
          <h3 className="mb-4 font-bold">Mina ansökningar</h3>
          {apps.length === 0 ? (
            <p className="text-sm text-muted-foreground">Inget att visa ännu.</p>
          ) : (
            <ul className="space-y-3">
              {apps.map((a) => (
                <li
                  key={a.id}
                  id={`app-${a.id}`}
                  className={`rounded-md border p-3 text-sm ${hash === `app-${a.id}` ? "border-violet-400 bg-violet-500/10" : ""}`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-semibold">{a.title}</span>
                    <span className={`rounded-full px-2 py-0.5 text-xs ${statusClass[a.status]}`}>{statusLabel[a.status]}</span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Skickad {new Date(a.created_at).toLocaleString("sv-SE")}
                    {a.status !== "pending" && <> · Besked {new Date(a.updated_at).toLocaleString("sv-SE")}</>}
                  </div>
                  {a.staff_note && (
                    <div className="mt-2 rounded bg-secondary/60 px-3 py-2">
                      <div className="text-xs font-semibold text-muted-foreground">Svar från staff</div>
                      <p className="mt-1 whitespace-pre-wrap">{a.staff_note}</p>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>

        <button onClick={() => signOut()} className="text-sm text-muted-foreground underline-offset-4 hover:underline">
          Logga ut
        </button>
      </div>
    </Layout>
  );
}
