import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { useAuth } from "@/lib/auth";
import { supabase, type StaffLog } from "@/lib/supabase";
import { SITE_NAME } from "@/lib/site";
import { DOC_TYPE_LABELS, type DocType } from "@/lib/permissions";

export const Route = createFileRoute("/staff/dokumentation")({
  head: () => ({
    meta: [{ title: `Dokumentation – ${SITE_NAME}` }],
  }),
  component: DocsPage,
});

function DocsPage() {
  const { user, isStaff, canDoc, loading } = useAuth();
  const [logs, setLogs] = useState<StaffLog[]>([]);
  const [docType, setDocType] = useState<DocType>("ban");
  const [targetDiscord, setTargetDiscord] = useState("");
  const [targetName, setTargetName] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [amount, setAmount] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user || !isStaff) return;
    load();
  }, [user, isStaff]);

  async function load() {
    const { data, error } = await supabase
      .from("staff_logs")
      .select("*, profiles(*)")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) {
      console.error(error);
      return;
    }
    setLogs((data as StaffLog[]) ?? []);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !canDoc) return;
    setSaving(true);
    const { error } = await supabase.from("staff_logs").insert({
      created_by: user.id,
      target_discord: targetDiscord || null,
      target_name: targetName || null,
      doc_type: docType,
      title: title || DOC_TYPE_LABELS[docType],
      body,
      amount: amount ? Number(amount) : null,
    });
    setSaving(false);
    if (error) {
      alert("Kunde inte spara: " + error.message);
      return;
    }
    setTitle("");
    setBody("");
    setTargetDiscord("");
    setTargetName("");
    setAmount("");
    load();
  }

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!user || !isStaff) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader
        eyebrow="Staff"
        title="Dokumentation"
        intro="Helper, mod, staff, admin m.fl. kan dokumentera bans, unbans, donationer, varningar och mer."
      />
      <StaffNav />

      {canDoc && (
        <form onSubmit={submit} className="glass mx-auto mt-8 max-w-2xl space-y-4 rounded-lg p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium">Typ</label>
              <select
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={docType}
                onChange={(e) => setDocType(e.target.value as DocType)}
              >
                {(Object.keys(DOC_TYPE_LABELS) as DocType[]).map((k) => (
                  <option key={k} value={k}>
                    {DOC_TYPE_LABELS[k]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Belopp (donation, valfritt)</label>
              <input
                type="number"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="t.ex. 150"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium">Discord-användare</label>
              <input
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={targetDiscord}
                onChange={(e) => setTargetDiscord(e.target.value)}
                placeholder="@användare eller ID"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Namn / karaktär</label>
              <input
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={targetName}
                onChange={(e) => setTargetName(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Rubrik</label>
            <input
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Kort rubrik"
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Beskrivning *</label>
            <textarea
              required
              rows={4}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Vad hände / vad gjordes..."
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full rounded-md bg-primary px-5 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            {saving ? "Sparar…" : "Spara dokumentation"}
          </button>
        </form>
      )}

      {!canDoc && (
        <p className="mt-6 text-center text-sm text-muted-foreground">
          Din roll får inte skapa dokumentation.
        </p>
      )}

      <div className="mx-auto mt-10 max-w-3xl space-y-3">
        <h2 className="font-bold">Senaste poster</h2>
        {logs.length === 0 && (
          <p className="text-sm text-muted-foreground">Inga poster ännu.</p>
        )}
        {logs.map((log) => (
          <div key={log.id} className="glass rounded-lg p-4 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="rounded-full bg-secondary px-2 py-0.5 text-xs font-semibold">
                {DOC_TYPE_LABELS[log.doc_type] ?? log.doc_type}
              </span>
              <span className="text-xs text-muted-foreground">
                {new Date(log.created_at).toLocaleString("sv-SE")}
                {log.profiles?.discord_username && <> · av @{log.profiles.discord_username}</>}
              </span>
            </div>
            <p className="mt-2 font-semibold">{log.title}</p>
            {(log.target_discord || log.target_name) && (
              <p className="text-muted-foreground">
                Mot: {log.target_name || ""} {log.target_discord ? `(${log.target_discord})` : ""}
              </p>
            )}
            {log.amount != null && <p className="text-muted-foreground">Belopp: {log.amount} kr</p>}
            <p className="mt-2 whitespace-pre-wrap">{log.body}</p>
          </div>
        ))}
      </div>
    </Layout>
  );
}
