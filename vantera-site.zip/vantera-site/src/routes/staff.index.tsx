import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { useAuth } from "@/lib/auth";
import { answersOf, supabase, type Application } from "@/lib/supabase";
import { statusClass, statusLabel } from "@/lib/notifications";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/staff/")({
  head: () => ({ meta: [{ title: `Staff-panel – ${SITE_NAME}` }] }),
  component: StaffPage,
});

type Filter = "pending" | "approved" | "denied" | "all";

function StaffPage() {
  const { user, isStaff, loading } = useAuth();
  const [apps, setApps] = useState<Application[]>([]);
  const [filter, setFilter] = useState<Filter>("pending");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [note, setNote] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    // Databasen (RLS) skickar bara ärenden som din roll får hantera
    let q = supabase.from("applications").select("*, profiles!applications_user_id_fkey(*)").order("created_at", { ascending: false }).limit(200);
    if (filter !== "all") q = q.eq("status", filter);
    const { data, error } = await q;
    if (error) {
      console.error(error);
      setMsg("Kunde inte hämta ansökningar: " + error.message);
      return;
    }
    setApps((data as unknown as Application[]) ?? []);
  }, [filter]);

  useEffect(() => {
    if (user && isStaff) void load();
  }, [user, isStaff, load]);

  async function decide(app: Application, status: "approved" | "denied") {
    const text = (note[app.id] ?? "").trim();
    if (status === "denied" && !text) {
      setMsg("Skriv en kort motivering innan du nekar, den visas för den sökande.");
      return;
    }
    setBusyId(app.id);
    setMsg(null);
    const { error } = await supabase.from("applications").update({ status, staff_note: text || null }).eq("id", app.id);
    if (error) {
      setBusyId(null);
      setMsg("Kunde inte uppdatera: " + error.message);
      return;
    }
    // DM till den sökande, ev. resultatkanal och automatisk roll vid godkänd
    const { data, error: fnError } = await supabase.functions.invoke("application-event", {
      body: { type: "decided", application_id: app.id },
    });
    setBusyId(null);
    if (fnError || data?.error) {
      setMsg("Ansökan är uppdaterad, men Discord-beskedet kunde inte skickas: " + (fnError?.message ?? data?.error));
    } else {
      setMsg(
        `Ansökan ${status === "approved" ? "godkänd" : "nekad"}.` +
          (data?.dmSent === false ? " Obs: DM kunde inte skickas (personen har stängt DM) – beskedet syns i Min portal." : "") +
          (data?.roleGiven ? " Rollen har delats ut." : ""),
      );
    }
    void load();
  }

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!user || !isStaff) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader
        eyebrow="Staff"
        title="Hantera ansökningar"
        intro="Du ser bara de ärenden din Discord-roll får hantera. Medlemskapsansvarig ser t.ex. bara medlemsansökningar."
      />
      <StaffNav />

      <div className="mx-auto mt-6 flex max-w-4xl flex-wrap gap-2">
        {(["pending", "approved", "denied", "all"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-md px-3 py-1.5 text-sm font-medium ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
          >
            {f === "pending" ? "Väntande" : f === "approved" ? "Godkända" : f === "denied" ? "Nekade" : "Alla"}
          </button>
        ))}
      </div>

      {msg && <div className="mx-auto mt-4 max-w-4xl rounded-md border border-violet-500/40 bg-violet-500/10 px-4 py-3 text-sm">{msg}</div>}

      <div className="mx-auto mt-6 max-w-4xl space-y-4">
        {apps.length === 0 && <p className="text-center text-muted-foreground">Inga ansökningar i den här listan.</p>}

        {apps.map((app) => (
          <div key={app.id} className="glass rounded-lg p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h3 className="font-bold">{app.title}</h3>
                <p className="text-xs text-muted-foreground">
                  {new Date(app.created_at).toLocaleString("sv-SE")}
                  {app.profiles?.discord_username && <> · @{app.profiles.discord_username}</>}
                  {app.profiles?.discord_id && <> · ID {app.profiles.discord_id}</>}
                </p>
              </div>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusClass[app.status]}`}>{statusLabel[app.status]}</span>
            </div>

            <dl className="mt-4 space-y-3 text-sm">
              {answersOf(app.data).map((a, i) => (
                <div key={i}>
                  <dt className="font-medium text-muted-foreground">{a.label}</dt>
                  <dd className="whitespace-pre-wrap">{a.value}</dd>
                </div>
              ))}
            </dl>

            {app.status === "pending" ? (
              <div className="mt-4 space-y-3 border-t border-border pt-4">
                <textarea
                  placeholder="Svar till den sökande (visas i Min portal och i DM). Krävs vid nekande."
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  rows={3}
                  value={note[app.id] ?? ""}
                  onChange={(e) => setNote((n) => ({ ...n, [app.id]: e.target.value }))}
                />
                <div className="flex gap-2">
                  <button
                    disabled={busyId === app.id}
                    onClick={() => void decide(app, "approved")}
                    className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
                  >
                    Godkänn
                  </button>
                  <button
                    disabled={busyId === app.id}
                    onClick={() => void decide(app, "denied")}
                    className="rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
                  >
                    Neka
                  </button>
                </div>
              </div>
            ) : (
              app.staff_note && <p className="mt-3 text-sm text-muted-foreground">Svar till den sökande: {app.staff_note}</p>
            )}
          </div>
        ))}
      </div>
    </Layout>
  );
}
