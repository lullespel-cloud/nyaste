import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";
import { Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { Field, inputCls } from "@/components/fields";
import { useAuth } from "@/lib/auth";
import { supabase, type FormRow } from "@/lib/supabase";
import { HANDLER_CHOICES, ROLE_LABELS } from "@/lib/permissions";
import type { FormField, FieldType } from "@/lib/default-forms";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/staff/formular")({
  head: () => ({ meta: [{ title: `Formulär – ${SITE_NAME}` }] }),
  component: FormsAdmin,
});

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/å|ä/g, "a")
    .replace(/ö/g, "o")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);

const emptyForm = (): FormRow => ({
  slug: "",
  category: "ansokningar",
  title: "",
  description: "",
  fields: [{ id: "svar", label: "Din ansökan", type: "textarea", required: true }],
  handler_roles: [],
  enabled: true,
  sort: 100,
});

function FormsAdmin() {
  const { user, canEdit, loading } = useAuth();
  const [forms, setForms] = useState<FormRow[]>([]);
  const [editing, setEditing] = useState<FormRow | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from("forms").select("*").order("sort", { ascending: true });
    if (error) setMsg("Kunde inte hämta formulär: " + error.message);
    else setForms((data as FormRow[]) ?? []);
  }, []);

  useEffect(() => {
    if (user && canEdit) void load();
  }, [user, canEdit, load]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }
  if (!user || !canEdit) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess text="Bara Ägare, Delägare, Head Admin och Admin kan redigera formulär." />
      </Layout>
    );
  }

  const patch = (p: Partial<FormRow>) => setEditing((f) => (f ? { ...f, ...p } : f));
  const setField = (i: number, p: Partial<FormField>) =>
    setEditing((f) => (f ? { ...f, fields: f.fields.map((x, idx) => (idx === i ? { ...x, ...p } : x)) } : f));
  const moveField = (i: number, dir: -1 | 1) =>
    setEditing((f) => {
      if (!f) return f;
      const j = i + dir;
      if (j < 0 || j >= f.fields.length) return f;
      const next = [...f.fields];
      const a = next[i];
      const b = next[j];
      if (!a || !b) return f;
      next[i] = b;
      next[j] = a;
      return { ...f, fields: next };
    });

  async function save() {
    if (!editing) return;
    const slug = isNew ? slugify(editing.slug || editing.title) : editing.slug;
    if (!slug || !editing.title.trim()) {
      setMsg("Formuläret behöver en titel.");
      return;
    }
    // Se till att varje fråga har ett unikt id (skapas från texten första gången)
    const used = new Set<string>();
    const fields = editing.fields
      .filter((f) => f.label.trim())
      .map((f, i) => {
        let id = f.id && f.id !== "svar" ? f.id : slugify(f.label) || `fraga-${i + 1}`;
        while (used.has(id)) id += "-2";
        used.add(id);
        const out: FormField = { id, label: f.label.trim(), type: f.type ?? "text" };
        if (f.required) out.required = true;
        if (f.type === "select") out.options = (f.options ?? []).map((o) => o.trim()).filter(Boolean);
        if (f.placeholder?.trim()) out.placeholder = f.placeholder.trim();
        if (f.help?.trim()) out.help = f.help.trim();
        return out;
      });
    if (fields.length === 0) {
      setMsg("Lägg till minst en fråga.");
      return;
    }
    setSaving(true);
    const row = { ...editing, slug, fields };
    const { error } = await supabase.from("forms").upsert(row, { onConflict: "slug" });
    setSaving(false);
    if (error) {
      setMsg("Kunde inte spara: " + error.message);
      return;
    }
    setMsg("Sparat!");
    setEditing(null);
    void load();
  }

  async function remove(slug: string) {
    if (!window.confirm(`Ta bort formuläret "${slug}"? Redan skickade ansökningar finns kvar men går inte att hantera om ingen redaktör finns.`)) return;
    const { error } = await supabase.from("forms").delete().eq("slug", slug);
    if (error) setMsg("Kunde inte ta bort: " + error.message);
    else {
      setEditing(null);
      void load();
    }
  }

  return (
    <Layout>
      <PageHeader eyebrow="Staff" title="Formulär" intro="Lägg till, ändra och stäng formulär. Välj vilka Discord-roller som får hantera varje formulär. Ägare, Delägare, Head Admin och Admin kan alltid hantera alla." />
      <StaffNav />
      {msg && <div className="mx-auto mt-4 max-w-4xl rounded-md border border-violet-500/40 bg-violet-500/10 px-4 py-3 text-sm">{msg}</div>}

      {!editing ? (
        <div className="mx-auto mt-6 max-w-4xl space-y-3">
          <button
            onClick={() => {
              setEditing(emptyForm());
              setIsNew(true);
              setMsg(null);
            }}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
          >
            <Plus className="h-4 w-4" /> Nytt formulär
          </button>
          {forms.map((f) => (
            <button
              key={f.slug}
              onClick={() => {
                setEditing(structuredClone(f));
                setIsNew(false);
                setMsg(null);
              }}
              className="glass flex w-full items-center justify-between gap-3 rounded-lg p-4 text-left hover:bg-accent/50"
            >
              <div>
                <div className="font-semibold">{f.title}</div>
                <div className="text-xs text-muted-foreground">
                  {f.category === "ansokningar" ? "Ansökningar" : "Serversupport"} · {f.fields.length} frågor · hanteras av{" "}
                  {f.handler_roles.length ? f.handler_roles.map((r) => ROLE_LABELS[r] ?? r).join(", ") : "ledningen"}
                </div>
              </div>
              <span className={`rounded-full px-2 py-0.5 text-xs ${f.enabled ? "bg-emerald-500/20 text-emerald-200" : "bg-slate-500/20 text-slate-200"}`}>
                {f.enabled ? "Öppet" : "Stängt"}
              </span>
            </button>
          ))}
        </div>
      ) : (
        <div className="glass mx-auto mt-6 max-w-3xl space-y-5 rounded-lg p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Titel" required>
              <input className={inputCls} value={editing.title} onChange={(e) => patch({ title: e.target.value })} />
            </Field>
            <Field label="Kategori">
              <select className={inputCls} value={editing.category} onChange={(e) => patch({ category: e.target.value as FormRow["category"] })}>
                <option value="ansokningar">Ansökningar</option>
                <option value="serversupport">Serversupport</option>
              </select>
            </Field>
          </div>
          <Field label="Beskrivning (visas ovanför formuläret)">
            <textarea className={inputCls} rows={2} value={editing.description} onChange={(e) => patch({ description: e.target.value })} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Sortering (lägst först)">
              <input type="number" className={inputCls} value={editing.sort} onChange={(e) => patch({ sort: Number(e.target.value) })} />
            </Field>
            <label className="flex items-end gap-2 pb-2 text-sm">
              <input type="checkbox" checked={editing.enabled} onChange={(e) => patch({ enabled: e.target.checked })} /> Formuläret är öppet
            </label>
          </div>

          <div>
            <div className="mb-2 text-sm font-medium">Roller som får hantera (utöver ledningen)</div>
            <div className="flex flex-wrap gap-3">
              {HANDLER_CHOICES.map((r) => (
                <label key={r} className="flex items-center gap-1.5 text-sm">
                  <input
                    type="checkbox"
                    checked={editing.handler_roles.includes(r)}
                    onChange={(e) => patch({ handler_roles: e.target.checked ? [...editing.handler_roles, r] : editing.handler_roles.filter((x) => x !== r) })}
                  />
                  {ROLE_LABELS[r]}
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <div className="text-sm font-medium">Frågor</div>
            {editing.fields.map((f, i) => (
              <div key={i} className="rounded-md border p-3">
                <div className="flex gap-2">
                  <input className={inputCls} placeholder="Frågetext" value={f.label} onChange={(e) => setField(i, { label: e.target.value })} />
                  <select className={`${inputCls} w-40`} value={f.type ?? "text"} onChange={(e) => setField(i, { type: e.target.value as FieldType })}>
                    <option value="text">Kort text</option>
                    <option value="textarea">Lång text</option>
                    <option value="select">Val (lista)</option>
                    <option value="number">Nummer</option>
                  </select>
                </div>
                {f.type === "select" && (
                  <input
                    className={`${inputCls} mt-2`}
                    placeholder="Alternativ, separera med komma: Ja, Nej"
                    value={(f.options ?? []).join(", ")}
                    onChange={(e) => setField(i, { options: e.target.value.split(",") })}
                  />
                )}
                <div className="mt-2 flex items-center justify-between">
                  <label className="flex items-center gap-1.5 text-sm">
                    <input type="checkbox" checked={!!f.required} onChange={(e) => setField(i, { required: e.target.checked })} /> Obligatorisk
                  </label>
                  <div className="flex gap-1">
                    <button type="button" onClick={() => moveField(i, -1)} className="rounded p-1.5 hover:bg-accent" aria-label="Flytta upp">
                      <ArrowUp className="h-4 w-4" />
                    </button>
                    <button type="button" onClick={() => moveField(i, 1)} className="rounded p-1.5 hover:bg-accent" aria-label="Flytta ned">
                      <ArrowDown className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => patch({ fields: editing.fields.filter((_, idx) => idx !== i) })}
                      className="rounded p-1.5 text-red-300 hover:bg-accent"
                      aria-label="Ta bort fråga"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={() => patch({ fields: [...editing.fields, { id: "", label: "", type: "text" }] })}
              className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm font-semibold hover:bg-accent"
            >
              <Plus className="h-4 w-4" /> Lägg till fråga
            </button>
          </div>

          <div className="flex flex-wrap gap-2 border-t pt-4">
            <button onClick={() => void save()} disabled={saving} className="rounded-md bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50">
              {saving ? "Sparar…" : "Spara"}
            </button>
            <button onClick={() => setEditing(null)} className="rounded-md border px-5 py-2.5 text-sm font-semibold hover:bg-accent">
              Avbryt
            </button>
            {!isNew && (
              <button onClick={() => void remove(editing.slug)} className="ml-auto rounded-md border border-red-500/40 px-4 py-2.5 text-sm font-semibold text-red-300 hover:bg-red-500/10">
                Ta bort formulär
              </button>
            )}
          </div>
        </div>
      )}
    </Layout>
  );
}
