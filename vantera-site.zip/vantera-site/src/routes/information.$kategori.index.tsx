import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { FileText } from "lucide-react";
import { Layout, PageHeader } from "@/components/Layout";
import { informationCategories, usePages } from "@/lib/content";
import { SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/information/$kategori/")({
  loader: ({ params }) => {
    if (!(params.kategori in informationCategories)) throw notFound();
    return null;
  },
  head: () => ({ meta: [{ title: `Regler & information – ${SITE_NAME}` }] }),
  component: Page,
});

function Page() {
  const { kategori } = Route.useParams();
  const cat = informationCategories[kategori as keyof typeof informationCategories];
  const { pages, loading } = usePages(kategori as "regler" | "information");

  return (
    <Layout>
      <PageHeader eyebrow={cat.label} title={cat.title} intro={cat.intro} back={<Link to="/information">← Information</Link>} />
      {loading ? (
        <p className="mt-12 text-center text-muted-foreground">Laddar…</p>
      ) : (
        <div className="mx-auto mt-12 grid max-w-4xl gap-5 md:grid-cols-2">
          {pages.map((t) => (
            <Link key={t.slug} to="/information/$kategori/$slug" params={{ kategori, slug: t.slug }} className="glass rounded-lg p-5 transition-transform hover:-translate-y-1">
              <div className="w-fit rounded-md bg-secondary p-2.5">
                <FileText className="h-5 w-5" />
              </div>
              <h2 className="mt-4 text-lg font-bold">{t.title}</h2>
              {t.staff_only && <span className="mt-2 inline-block rounded-md border border-violet-500/40 bg-violet-500/10 px-2 py-0.5 text-xs font-semibold text-violet-200">Endast staff</span>}
              <div className="mt-4 border-t pt-4 text-sm text-muted-foreground">{t.meta}</div>
            </Link>
          ))}
        </div>
      )}
    </Layout>
  );
}
