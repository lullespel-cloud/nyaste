import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { FileText } from "lucide-react";
import { Layout, PageHeader, LoggedInBanner, LoginPrompt } from "@/components/Layout";
import { SITE_NAME } from "@/lib/site";
import { applicationCategories, useForms } from "@/lib/content";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/ansokningar/$kategori/")({
  loader: ({ params }) => {
    if (!(params.kategori in applicationCategories)) throw notFound();
    return null;
  },
  head: () => ({ meta: [{ title: `Formulär – ${SITE_NAME}` }] }),
  component: Page,
});

function Page() {
  const { kategori } = Route.useParams();
  const cat = applicationCategories[kategori as keyof typeof applicationCategories];
  const { forms, loading } = useForms();
  const { user } = useAuth();
  const list = forms.filter((f) => f.category === kategori && f.enabled);

  return (
    <Layout>
      <PageHeader eyebrow={cat.label} title={cat.title} intro={cat.intro} back={<Link to="/ansokningar">← Ansökningar</Link>} />
      {user ? <LoggedInBanner /> : <LoginPrompt />}
      {loading ? (
        <p className="mt-12 text-center text-muted-foreground">Laddar…</p>
      ) : (
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {list.map((f) => (
            <Link
              key={f.slug}
              to="/ansokningar/$kategori/$slug"
              params={{ kategori, slug: f.slug }}
              className="glass flex flex-col rounded-lg p-5 transition-transform hover:-translate-y-1"
            >
              <div className="w-fit rounded-md bg-secondary p-2.5">
                <FileText className="h-5 w-5" />
              </div>
              <h2 className="mt-4 text-lg font-bold">{f.title}</h2>
              <p className="mt-2 flex-1 text-sm text-muted-foreground">{f.description}</p>
              <div className="mt-4 border-t pt-4 text-sm">Öppna formulär →</div>
            </Link>
          ))}
          {list.length === 0 && <p className="col-span-full text-center text-muted-foreground">Inga formulär här just nu.</p>}
        </div>
      )}
    </Layout>
  );
}
