import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Avatar, Layout, PageHeader } from "@/components/Layout";
import { NoAccess, StaffNav } from "@/components/StaffNav";
import { useAuth } from "@/lib/auth";
import { supabase, type Profile } from "@/lib/supabase";
import { ROLE_LABELS } from "@/lib/permissions";
import { SITE_NAME } from "@/lib/site";
import { inputCls } from "@/components/fields";

export const Route = createFileRoute("/staff/medlemmar")({
  head: () => ({ meta: [{ title: `Medlemmar – ${SITE_NAME}` }] }),
  component: MembersPage,
});

function MembersPage() {
  const { user, isStaff, loading } = useAuth();
  const [rows, setRows] = useState<Profile[]>([]);
  const [q, setQ] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user || !isStaff) return;
    supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500)
      .then(({ data, error: e }) => {
        if (e) setError(e.message);
        else setRows((data as Profile[]) ?? []);
      });
  }, [user, isStaff]);

  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return rows;
    return rows.filter((p) => [p.discord_username, p.display_name, p.discord_id].some((v) => v?.toLowerCase().includes(t)));
  }, [rows, q]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }
  if (!user || !isStaff) {
    return (
      <Layout>
        <PageHeader eyebrow="Staff" title="Ingen behörighet" />
        <NoAccess />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader eyebrow="Staff" title="Medlemmar" intro="Alla som loggat in på sajten och deras roller från Discord. Roller ändras i Discord, inte här." />
      <StaffNav />
      <div className="mx-auto mt-6 max-w-4xl">
        <input className={inputCls} placeholder="Sök på namn eller Discord-ID…" value={q} onChange={(e) => setQ(e.target.value)} />
        {error && <p className="mt-3 text-sm text-red-300">{error}</p>}
        <div className="mt-4 space-y-2">
          {shown.map((p) => (
            <div key={p.id} className="glass flex flex-wrap items-center gap-3 rounded-lg p-3 text-sm">
              <Avatar src={p.avatar_url} name={p.display_name || p.discord_username || "?"} className="h-9 w-9" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{p.display_name || p.discord_username}</div>
                <div className="truncate text-xs text-muted-foreground">
                  @{p.discord_username} · {p.discord_id}
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                {(p.roles ?? []).filter((r) => ROLE_LABELS[r] && r !== "medlem").map((r) => (
                  <span key={r} className="rounded-full border border-violet-500/40 bg-violet-500/10 px-2 py-0.5 text-xs text-violet-200">
                    {ROLE_LABELS[r]}
                  </span>
                ))}
              </div>
              <div className="text-xs text-muted-foreground">{p.in_guild === false ? "Ej i Discord" : p.status}</div>
            </div>
          ))}
          {shown.length === 0 && <p className="text-center text-sm text-muted-foreground">Inga träffar.</p>}
        </div>
      </div>
    </Layout>
  );
}
