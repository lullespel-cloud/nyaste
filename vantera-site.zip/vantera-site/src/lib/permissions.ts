/**
 * Vantera Roleplay – roller & behörigheter
 *
 * Rollerna kommer från Discord (edge-funktionen "sync-roles") och sparas i profiles.roles.
 * Den här filen styr bara vad som VISAS i gränssnittet. Det som faktiskt är tillåtet avgörs av
 * databasens regler (RLS) i supabase/schema.sql, så att ingen kan kringgå det i webbläsaren.
 *
 * Hierarki (högst → lägst):
 * ägare → delägare → head admin → admin → head mod → mod → helper
 * Special: medlemskapsansvarig, krimansvarig, donationsansvarig, servervakt
 */

export type Role =
  | "ägare"
  | "delägare"
  | "head admin"
  | "admin"
  | "head mod"
  | "mod"
  | "helper"
  | "medlemskapsansvarig"
  | "krimansvarig"
  | "donationsansvarig"
  | "staff"
  | "medlem"
  | "kriminell"
  | "servervakt";

/** Ägare / delägare / head admin / admin – redigerar formulär, regler, prislista och ser loggar */
export const CONTENT_EDITORS: Role[] = ["ägare", "delägare", "head admin", "admin"];

/** Alla staff-nivåer (ser staff-menyn) */
export const STAFF_LEVEL: Role[] = [
  "ägare",
  "delägare",
  "head admin",
  "admin",
  "head mod",
  "mod",
  "helper",
  "medlemskapsansvarig",
  "krimansvarig",
  "donationsansvarig",
  "staff",
  "servervakt",
];

/** Får dokumentera ban / unban / donation / varning m.m. */
export const DOC_ROLES: Role[] = STAFF_LEVEL;

/** Rollerna som kan väljas som "hanterare" när man redigerar ett formulär (editors har alltid tillgång) */
export const HANDLER_CHOICES: Role[] = [
  "head mod",
  "mod",
  "helper",
  "medlemskapsansvarig",
  "krimansvarig",
  "donationsansvarig",
  "staff",
  "servervakt",
];

export const ROLE_LABELS: Record<string, string> = {
  "ägare": "Ägare",
  "delägare": "Delägare",
  "head admin": "Head Admin",
  admin: "Admin",
  "head mod": "Head Mod",
  mod: "Mod",
  helper: "Helper",
  medlemskapsansvarig: "Medlemskapsansvarig",
  krimansvarig: "Krimansvarig",
  donationsansvarig: "Donationsansvarig",
  staff: "Staff",
  servervakt: "Servervakt",
  medlem: "Medlem",
  kriminell: "Kriminell",
};

export type DocType = "ban" | "unban" | "donation" | "kick" | "warn" | "note" | "whitelist" | "other";

export const DOC_TYPE_LABELS: Record<DocType, string> = {
  ban: "Ban",
  unban: "Unban",
  donation: "Donation",
  kick: "Kick",
  warn: "Varning",
  note: "Anteckning",
  whitelist: "Whitelist",
  other: "Övrigt",
};

export function normalizeRoles(roles: string[] | null | undefined): string[] {
  return (roles ?? []).map((r) => r.toLowerCase().trim());
}

export function hasAnyRole(userRoles: string[] | null | undefined, allowed: readonly string[]): boolean {
  const lower = normalizeRoles(userRoles);
  return allowed.some((a) => lower.includes(a.toLowerCase()));
}

export function isStaffLevel(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, STAFF_LEVEL);
}

export function canEditContent(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, CONTENT_EDITORS);
}

export function canDocument(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, DOC_ROLES);
}

/** Editors får hantera allt, övriga bara formulär där deras roll står i handler_roles. */
export function canHandleWith(userRoles: string[] | null | undefined, handlerRoles: string[] | null | undefined): boolean {
  return canEditContent(userRoles) || hasAnyRole(userRoles, handlerRoles ?? []);
}
