import type { ReactNode } from "react";

/**
 * Enkel textrenderare för regler/information (inget HTML, inga beroenden).
 *  ## Rubrik   ### Underrubrik   - punkt   1. punkt   > notering   **fet**
 *  Rader med " | " blir tabeller (första raden är rubrikraden).
 */
function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
    part.startsWith("**") && part.endsWith("**") && part.length > 4 ? (
      <strong key={i}>{part.slice(2, -2)}</strong>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

type Block =
  | { t: "h2" | "h3" | "p" | "quote"; text: string }
  | { t: "ul" | "ol"; items: string[] }
  | { t: "table"; rows: string[][] };

export function parseBlocks(src: string): Block[] {
  const lines = src.replace(/\r/g, "").split("\n");
  const blocks: Block[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = (lines[i] ?? "").trimEnd();
    if (!line.trim()) {
      i++;
      continue;
    }
    if (line.startsWith("### ")) {
      blocks.push({ t: "h3", text: line.slice(4) });
      i++;
    } else if (line.startsWith("## ")) {
      blocks.push({ t: "h2", text: line.slice(3) });
      i++;
    } else if (line.startsWith("> ")) {
      blocks.push({ t: "quote", text: line.slice(2) });
      i++;
    } else if (/^[-•] /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^[-•] /.test(lines[i] ?? "")) items.push((lines[i] ?? "").slice(2)), i++;
      blocks.push({ t: "ul", items });
    } else if (/^\d+\. /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\. /.test(lines[i] ?? "")) items.push((lines[i] ?? "").replace(/^\d+\. /, "")), i++;
      blocks.push({ t: "ol", items });
    } else if (line.includes(" | ")) {
      const rows: string[][] = [];
      while (i < lines.length && (lines[i] ?? "").includes(" | ")) rows.push((lines[i] ?? "").split("|").map((c) => c.trim())), i++;
      blocks.push({ t: "table", rows });
    } else {
      const para: string[] = [line];
      i++;
      while (i < lines.length && (lines[i] ?? "").trim() && !/^(#{2,3} |> |[-•] |\d+\. )/.test(lines[i] ?? "") && !(lines[i] ?? "").includes(" | ")) {
        para.push((lines[i] ?? "").trim());
        i++;
      }
      blocks.push({ t: "p", text: para.join(" ") });
    }
  }
  return blocks;
}

export function RichText({ text }: { text: string }) {
  const blocks = parseBlocks(text);
  return (
    <div className="space-y-4 leading-relaxed">
      {blocks.map((b, idx) => {
        switch (b.t) {
          case "h2":
            return (
              <h2 key={idx} className="pt-4 text-xl font-bold first:pt-0">
                {inline(b.text)}
              </h2>
            );
          case "h3":
            return (
              <h3 key={idx} className="pt-2 text-lg font-semibold">
                {inline(b.text)}
              </h3>
            );
          case "quote":
            return (
              <div key={idx} className="rounded-lg border border-violet-500/30 bg-violet-500/10 px-4 py-3 text-sm">
                {inline(b.text)}
              </div>
            );
          case "ul":
            return (
              <ul key={idx} className="list-disc space-y-1.5 pl-6">
                {b.items.map((it, j) => (
                  <li key={j}>{inline(it)}</li>
                ))}
              </ul>
            );
          case "ol":
            return (
              <ol key={idx} className="list-decimal space-y-1.5 pl-6">
                {b.items.map((it, j) => (
                  <li key={j}>{inline(it)}</li>
                ))}
              </ol>
            );
          case "table": {
            const [head, ...rows] = b.rows;
            return (
              <div key={idx} className="overflow-x-auto rounded-lg border">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b">
                      {(head ?? []).map((c, j) => (
                        <th
                          key={j}
                          className={`px-3 py-3 font-semibold uppercase tracking-widest text-muted-foreground ${j === 0 ? "text-left" : "text-right"}`}
                        >
                          {c}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, j) => (
                      <tr key={j} className="border-b last:border-0">
                        {r.map((c, k) => (
                          <td key={k} className={`px-3 py-3 ${k === 0 ? "font-semibold uppercase tracking-wider" : "text-right"}`}>
                            {c}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          }
          default:
            return (
              <p key={idx} className="text-muted-foreground">
                {inline(b.text)}
              </p>
            );
        }
      })}
    </div>
  );
}
