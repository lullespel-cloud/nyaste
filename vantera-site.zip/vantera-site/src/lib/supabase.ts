import { createClient } from "@supabase/supabase-js";
import type { DocType } from "./permissions";
import type { FormField } from "./default-forms";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    "[Vantera] Saknar VITE_SUPABASE_URL eller VITE_SUPABASE_ANON_KEY. Skapa en .env-fil (se SETUP.md).",
  );
}

export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder",
);

export type Profile = {
  id: string;
  discord_id: string | null;
  discord_username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  roles: string[];
  discord_roles?: string[] | null;
  in_guild?: boolean | null;
  roles_synced_at?: string | null;
  status: string;
  created_at: string;
};

export type Answer = { id?: string; label: string; value: string };

export type Application = {
  id: string;
  user_id: string;
  category: string;
  form_slug: string;
  title: string;
  /** Ny typ: lista med {label, value}. Gamla ansökningar kan ha ett objekt. */
  data: Answer[] | Record<string, string>;
  status: "pending" | "approved" | "denied" | "closed";
  staff_note: string | null;
  handled_by: string | null;
  created_at: string;
  updated_at: string;
  profiles?: Profile | null;
};

export function answersOf(data: Application["data"] | null | undefined): Answer[] {
  if (!data) return [];
  if (Array.isArray(data)) return data;
  return Object.entries(data).map(([label, value]) => ({ label, value: String(value) }));
}

export type StaffLog = {
  id: string;
  created_by: string;
  target_discord: string | null;
  target_name: string | null;
  doc_type: DocType;
  title: string;
  body: string;
  amount: number | null;
  created_at: string;
  profiles?: Profile | null;
};

export type FormRow = {
  slug: string;
  category: "ansokningar" | "serversupport";
  title: string;
  description: string;
  fields: FormField[];
  handler_roles: string[];
  enabled: boolean;
  sort: number;
};

export type PageRow = {
  category: "regler" | "information";
  slug: string;
  title: string;
  meta: string;
  body: string;
  sort: number;
  staff_only: boolean;
  updated_at?: string | null;
};

export type AuditRow = {
  id: number;
  actor: string | null;
  action: string;
  target: string | null;
  detail: Record<string, unknown> | null;
  created_at: string;
  profiles?: Pick<Profile, "discord_username" | "display_name"> | null;
};
