import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase, type Profile } from "./supabase";
import { canDocument, canEditContent, isStaffLevel } from "./permissions";

const SYNC_EVERY_MS = 5 * 60 * 1000;

type AuthState = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  isStaff: boolean;
  canDoc: boolean;
  canEdit: boolean;
  syncing: boolean;
  syncError: string | null;
  signInWithDiscord: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  /** Hämtar dina riktiga Discord-roller igen och uppdaterar behörigheterna. */
  syncRoles: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const syncingRef = useRef(false);

  const fetchProfile = useCallback(async (userId: string) => {
    const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (error) {
      console.error("Kunde inte hämta profil:", error.message);
      return null;
    }
    return data as Profile | null;
  }, []);

  const syncRoles = useCallback(async () => {
    if (syncingRef.current) return;
    syncingRef.current = true;
    setSyncing(true);
    setSyncError(null);
    try {
      const { data, error } = await supabase.functions.invoke("sync-roles", { body: {} });
      if (error) throw new Error(error.message);
      if (data?.error) throw new Error(data.error);
      const {
        data: { session: s },
      } = await supabase.auth.getSession();
      if (s?.user) setProfile(await fetchProfile(s.user.id));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Kunde inte synka roller";
      console.warn("[Vantera] Rollsynk misslyckades:", msg);
      setSyncError(msg);
    } finally {
      syncingRef.current = false;
      setSyncing(false);
    }
  }, [fetchProfile]);

  const refreshProfile = useCallback(async () => {
    if (!session?.user?.id) {
      setProfile(null);
      return;
    }
    setProfile(await fetchProfile(session.user.id));
  }, [session, fetchProfile]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) fetchProfile(data.session.user.id).then(setProfile);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      if (newSession?.user) {
        // Rollerna hämtas från Discord av effekten nedan så fort profilen laddats (roles_synced_at saknas/är gammal)
        fetchProfile(newSession.user.id).then(setProfile);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  // Håll rollerna färska: synka om de är äldre än 5 min när sidan är öppen, och när fliken får fokus.
  useEffect(() => {
    if (!session?.user) return;
    const maybeSync = () => {
      const last = profile?.roles_synced_at ? new Date(profile.roles_synced_at).getTime() : 0;
      if (Date.now() - last > SYNC_EVERY_MS) void syncRoles();
    };
    maybeSync();
    const onFocus = () => maybeSync();
    window.addEventListener("focus", onFocus);
    const t = window.setInterval(maybeSync, SYNC_EVERY_MS);
    return () => {
      window.removeEventListener("focus", onFocus);
      window.clearInterval(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.user?.id, profile?.roles_synced_at]);

  const signInWithDiscord = useCallback(async () => {
    const redirectTo = `${window.location.origin}/portal`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "discord",
      options: { redirectTo, scopes: "identify email" },
    });
    if (error) {
      console.error("Discord-login fel:", error.message);
      alert("Kunde inte starta Discord-inloggning: " + error.message);
    }
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
  }, []);

  const rolesKey = (profile?.roles ?? []).join("|");
  const flags = useMemo(() => {
    const roles = rolesKey ? rolesKey.split("|") : [];
    return { isStaff: isStaffLevel(roles), canDoc: canDocument(roles), canEdit: canEditContent(roles) };
  }, [rolesKey]);

  const value: AuthState = {
    session,
    user: session?.user ?? null,
    profile,
    loading,
    isStaff: flags.isStaff,
    canDoc: flags.canDoc,
    canEdit: flags.canEdit,
    syncing,
    syncError,
    signInWithDiscord,
    signOut,
    refreshProfile,
    syncRoles,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth måste användas inom AuthProvider");
  return ctx;
}
