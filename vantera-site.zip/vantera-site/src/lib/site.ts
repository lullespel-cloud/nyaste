export const SITE_NAME = "Vantera Roleplay";
export const SHORT_NAME = "Vantera";
// Byt till er riktiga invite-länk (kan även sättas som VITE_DISCORD_URL i Netlify).
export const DISCORD_URL = (import.meta.env.VITE_DISCORD_URL as string | undefined) || "https://discord.gg/";
