import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase, type Application } from "./supabase";
import { useAuth } from "./auth";

export const statusLabel: Record<Application["status"], string> = {
  pending: "Väntar",
  approved: "Godkänd",
  denied: "Nekad",
  closed: "Stängd",
};

export const statusClass: Record<Application["status"], string> = {
  pending: "bg-amber-500/20 text-amber-200",
  approved: "bg-emerald-500/20 text-emerald-200",
  denied: "bg-red-500/20 text-red-200",
  closed: "bg-slate-500/20 text-slate-200",
};

const KEY = "vantera:notifications-read-at";

function readAt(): number {
  try {
    return Number(window.localStorage.getItem(KEY) ?? 0) || 0;
  } catch {
    return 0;
  }
}

/** Notiser = dina ansökningar som staff har avgjort. Oläst = avgjord efter senast du öppnade listan. */
export function useNotifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<Application[]>([]);
  const [lastRead, setLastRead] = useState(0);

  useEffect(() => {
    setLastRead(readAt());
  }, []);

  useEffect(() => {
    if (!user) {
      setItems([]);
      return;
    }
    let cancelled = false;
    const load = async () => {
      const { data } = await supabase
        .from("applications")
        .select("id, title, status, updated_at, form_slug, category, created_at, user_id, data, staff_note, handled_by")
        .eq("user_id", user.id)
        .neq("status", "pending")
        .order("updated_at", { ascending: false })
        .limit(15);
      if (!cancelled) setItems((data as Application[]) ?? []);
    };
    void load();
    const t = window.setInterval(load, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(t);
    };
  }, [user]);

  const isUnread = useCallback((a: Application) => new Date(a.updated_at).getTime() > lastRead, [lastRead]);
  const unreadCount = useMemo(() => items.filter(isUnread).length, [items, isUnread]);

  const markAllRead = useCallback(() => {
    const now = Date.now();
    try {
      window.localStorage.setItem(KEY, String(now));
    } catch {
      /* webbläsaren blockerar lagring – notisen visas bara som oläst igen */
    }
    setLastRead(now);
  }, []);

  return { items, unreadCount, isUnread, markAllRead };
}
