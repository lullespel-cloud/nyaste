// Standardformulär för Vantera Roleplay.
// Används som (1) startdata i databasen (scripts/gen-seed.mjs) och (2) reserv om databasen inte svarar.
// Efter första körningen redigerar ni formulären direkt på sajten: Staff → Formulär.
// Den här filen får inte importera något (den körs även av ett nodescript).

export type FieldType = "text" | "textarea" | "select" | "number";

export type FormField = {
  id: string;
  label: string;
  type?: FieldType;
  required?: boolean;
  options?: string[];
  placeholder?: string;
  help?: string;
};

export type FormDef = {
  slug: string;
  category: "ansokningar" | "serversupport";
  title: string;
  description: string;
  fields: FormField[];
  handler_roles: string[];
  enabled: boolean;
  sort: number;
};

// Roller som ALLTID får hantera alla formulär (ägare, delägare, head admin, admin) läggs på i databasen,
// så här anges bara de extra rollerna per formulär.
export const ALL_STAFF = [
  "helper",
  "mod",
  "head mod",
  "medlemskapsansvarig",
  "krimansvarig",
  "donationsansvarig",
  "staff",
  "servervakt",
];

const ja_nej = ["Ja", "Nej"];

export const DEFAULT_FORMS: FormDef[] = [
  {
    slug: "medlemskap",
    category: "ansokningar",
    title: "Medlemskapsansökan",
    description: "Ansök om att få spela på Vantera Roleplay. Läs reglerna först.",
    handler_roles: ["medlemskapsansvarig"],
    enabled: true,
    sort: 10,
    fields: [
      { id: "alder", label: "Hur gammal är du?", type: "number", required: true },
      { id: "steam", label: "Steam-namn eller Steam-ID", required: true },
      { id: "karaktar", label: "Karaktärsnamn", required: true },
      { id: "bakgrund", label: "Kort bakgrund för din karaktär", type: "textarea", required: true },
      { id: "erfarenhet", label: "Tidigare erfarenhet av rollspel", type: "textarea", required: true },
      { id: "regler", label: "Har du läst och förstått reglerna?", type: "select", options: ja_nej, required: true },
      { id: "rdmvdm", label: "Förklara med egna ord vad RDM och VDM är", type: "textarea", required: true },
      { id: "varfor", label: "Varför vill du spela på Vantera?", type: "textarea", required: true },
    ],
  },
  {
    slug: "kriminell",
    category: "ansokningar",
    title: "Kriminellansökan",
    description: "Ansök om kriminell roll. Berätta om din karaktär och hur du skapar rollspel för andra.",
    handler_roles: ["krimansvarig"],
    enabled: true,
    sort: 20,
    fields: [
      { id: "karaktar", label: "Karaktärsnamn", required: true },
      { id: "bakgrund", label: "Beskriv karaktärens bakgrund och hur den hamnade i kriminalitet", type: "textarea", required: true },
      { id: "mal", label: "Vilka mål har karaktären?", type: "textarea", required: true },
      { id: "erfarenhet", label: "Tidigare erfarenhet av kriminella roller", type: "textarea" },
      { id: "rollspel", label: "Hur skapar du bra rollspel för motparten, även när du förlorar?", type: "textarea", required: true },
      { id: "regler", label: "Vilka krimregler tycker du är viktigast och varför?", type: "textarea", required: true },
      { id: "scenario", label: "Scenario: Du blir omringad av polisen och har inga vapen kvar. Vad gör du?", type: "textarea", required: true },
    ],
  },
  {
    slug: "servervakt",
    category: "ansokningar",
    title: "Servervaktsansökan",
    description: "Ansök om att bli servervakt och hjälpa till med ordningen på servern.",
    handler_roles: ["head mod", "mod", "servervakt"],
    enabled: true,
    sort: 30,
    fields: [
      { id: "alder", label: "Hur gammal är du?", type: "number", required: true },
      { id: "erfarenhet", label: "Tidigare erfarenhet av liknande uppdrag", type: "textarea" },
      { id: "motivation", label: "Varför vill du bli servervakt?", type: "textarea", required: true },
      { id: "aktivitet", label: "Hur många timmar i veckan kan du vara aktiv?", required: true },
      { id: "scenario1", label: "Scenario: En spelare skriker i röstchatten och hotar andra. Vad gör du?", type: "textarea", required: true },
      { id: "scenario2", label: "Scenario: Två spelare är oense om en situation var RP eller inte. Hur löser du det?", type: "textarea", required: true },
    ],
  },
  {
    slug: "staff",
    category: "ansokningar",
    title: "Staffansökan",
    description: "Att vara staff på Vantera innebär att följa reglerna, samarbeta med teamet och vara aktiv.",
    handler_roles: ["head mod", "mod"],
    enabled: true,
    sort: 40,
    fields: [
      { id: "roll", label: "Vilken roll söker du?", type: "select", options: ["Helper", "Mod", "Admin"], required: true },
      { id: "alder", label: "Hur gammal är du?", type: "number", required: true },
      { id: "erfarenhet", label: "Tidigare erfarenhet som staff eller moderator", type: "textarea" },
      { id: "motivation", label: "Varför vill du bli staff?", type: "textarea", required: true },
      { id: "aktivitet", label: "Hur aktiv kan du vara, och vilka tider?", type: "textarea", required: true },
      { id: "scenario", label: "Scenario: En vän till dig bryter mot reglerna. Hur hanterar du det?", type: "textarea", required: true },
    ],
  },
  {
    slug: "jobb",
    category: "ansokningar",
    title: "Jobbansökan",
    description: "Ansök om att bli chef eller anställd inom ett yrke eller företag.",
    handler_roles: ["head mod", "mod"],
    enabled: true,
    sort: 50,
    fields: [
      { id: "jobb", label: "Vilket jobb eller företag?", type: "select", options: ["Polis", "Sjukvård", "Mekaniker", "Taxi", "Annat (skriv nedan)"], required: true },
      { id: "karaktar", label: "Karaktärsnamn", required: true },
      { id: "erfarenhet", label: "Tidigare erfarenhet av yrket i rollspel", type: "textarea" },
      { id: "motivation", label: "Varför just dig?", type: "textarea", required: true },
      { id: "annat", label: "Om du valde Annat, vilket jobb?" },
    ],
  },
  {
    slug: "medlemskapsansvarig",
    category: "ansokningar",
    title: "Ansökan om medlemskapsansvarig",
    description: "Ansök om rollen medlemskapsansvarig, som hanterar medlemsansökningar.",
    handler_roles: [],
    enabled: true,
    sort: 60,
    fields: [
      { id: "motivation", label: "Varför vill du ha den här rollen?", type: "textarea", required: true },
      { id: "aktivitet", label: "Hur aktiv kan du vara?", type: "textarea", required: true },
    ],
  },
  {
    slug: "banoverklagan",
    category: "serversupport",
    title: "Banöverklagan",
    description: "Be om en ny bedömning av din avstängning. Bara du och staff kan läsa ärendet.",
    handler_roles: ALL_STAFF,
    enabled: true,
    sort: 10,
    fields: [
      { id: "banid", label: "Ban-ID (om du har det)" },
      { id: "datum", label: "Ungefär när blev du bannad?", required: true },
      { id: "anledning", label: "Vilken anledning fick du?", type: "textarea", required: true },
      { id: "forklaring", label: "Varför bör banen omprövas?", type: "textarea", required: true },
      { id: "bevis", label: "Bevis eller länkar", type: "textarea" },
      { id: "tidigare", label: "Har du överklagat samma ban tidigare?", type: "select", options: ja_nej, required: true },
    ],
  },
  {
    slug: "staffanmalan",
    category: "serversupport",
    title: "Staffanmälan",
    description: "Anmäl missbruk av staff. Beskriv händelsen tydligt och bifoga länkar till bevis. Läses bara av ledningen.",
    handler_roles: [],
    enabled: true,
    sort: 20,
    fields: [
      { id: "vem", label: "Vilken staff gäller det?", required: true },
      { id: "beskrivning", label: "Beskriv händelsen", type: "textarea", required: true },
      { id: "bevis", label: "Bevis eller länkar", type: "textarea" },
    ],
  },
  {
    slug: "servervaktanmalan",
    category: "serversupport",
    title: "Servervaktanmälan",
    description: "Anmäl problem eller situationer som servervaktsansvarig bör ta del av.",
    handler_roles: ["head mod", "mod", "servervakt"],
    enabled: true,
    sort: 30,
    fields: [
      { id: "beskrivning", label: "Beskriv problemet", type: "textarea", required: true },
      { id: "bevis", label: "Bevis eller länkar", type: "textarea" },
    ],
  },
];
