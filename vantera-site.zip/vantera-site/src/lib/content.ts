import { useEffect, useState } from "react";
import { supabase, type FormRow, type PageRow } from "./supabase";
import { DEFAULT_FORMS } from "./default-forms";
import { DEFAULT_PAGES } from "./default-pages";
import { useAuth } from "./auth";

export const applicationCategories = {
  ansokningar: {
    label: "Ansökningar",
    title: "Välj formulär",
    intro: "Medlemskap, kriminell, servervakt, staff och mer.",
  },
  serversupport: {
    label: "Serversupport",
    title: "Välj formulär",
    intro: "Banöverklagan samt anmälningar av staff och servervakter.",
  },
} as const;

export const informationCategories = {
  regler: { label: "Regler", title: "Regler", intro: "Community-, Discord- och rollspelsregler." },
  information: { label: "Information", title: "Information", intro: "Praktisk information, köpvillkor och prislista." },
} as const;

const fallbackForms = (): FormRow[] => DEFAULT_FORMS.map((f) => ({ ...f, description: f.description }));
const fallbackPages = (): PageRow[] => DEFAULT_PAGES.map((p) => ({ ...p }));

/** Formulär från databasen. Faller tillbaka på standardformulären om databasen saknar tabellen/är tom. */
export function useForms() {
  const [forms, setForms] = useState<FormRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [fromDb, setFromDb] = useState(false);

  useEffect(() => {
    let cancelled = false;
    supabase
      .from("forms")
      .select("*")
      .order("sort", { ascending: true })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error || !data || data.length === 0) {
          setForms(fallbackForms());
          setFromDb(false);
        } else {
          setForms(data as FormRow[]);
          setFromDb(true);
        }
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { forms, loading, fromDb, setForms };
}

/** Sidor (regler/information) från databasen, med reservdata. Inloggning styr om staff-sidor syns. */
export function usePages(category?: "regler" | "information") {
  const { session, loading: authLoading } = useAuth();
  const [pages, setPages] = useState<PageRow[]>([]);
  const [loading, setLoading] = useState(true);

  const userId = session?.user?.id ?? null;
  useEffect(() => {
    if (authLoading) return;
    let cancelled = false;
    setLoading(true);
    let q = supabase.from("pages").select("*").order("sort", { ascending: true });
    if (category) q = q.eq("category", category);
    q.then(({ data, error }) => {
      if (cancelled) return;
      if (error || !data || data.length === 0) {
        setPages(fallbackPages().filter((p) => !p.staff_only && (!category || p.category === category)));
      } else {
        setPages(data as PageRow[]);
      }
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [category, userId, authLoading]);

  return { pages, loading };
}
