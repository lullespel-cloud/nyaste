import { Link } from "@tanstack/react-router";
import { Bell, LogOut, MessageCircle, Shield } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useNotifications, statusLabel, statusClass } from "@/lib/notifications";
import { SITE_NAME, DISCORD_URL } from "@/lib/site";
import { useAuth } from "@/lib/auth";

const nav = [
  { to: "/", label: "Hem", exact: true },
  { to: "/ansokningar", label: "Ansökningar" },
  { to: "/information", label: "Information" },
  { to: "/portal", label: "Min portal" },
] as const;

export function Layout({ children }: { children: ReactNode }) {
  const { user, profile, loading, isStaff, signInWithDiscord, signOut } = useAuth();

  const displayName =
    profile?.display_name ||
    profile?.discord_username ||
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.user_metadata?.preferred_username ||
    "Användare";

  const avatar = profile?.avatar_url || user?.user_metadata?.avatar_url || user?.user_metadata?.picture;

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-950 via-background to-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-4 pt-4">
        <header className="glass flex items-center gap-2 rounded-lg p-3">
          <nav className="grid flex-1 grid-cols-4 gap-1 text-sm font-semibold">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                activeOptions={{ exact: "exact" in n }}
                className="rounded-md px-3 py-2 transition-colors hover:bg-accent"
                activeProps={{ className: "bg-accent" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          {isStaff && (
            <Link
              to="/staff"
              className="hidden items-center gap-1 rounded-md border border-violet-500/40 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200 sm:flex"
            >
              <Shield className="h-3.5 w-3.5" /> Staff
            </Link>
          )}

          {user && <NotificationBell />}

          {loading ? (
            <div className="h-9 w-24 animate-pulse rounded-md bg-muted" />
          ) : user ? (
            <div className="flex items-center gap-1 pl-1">
              <Link
                to="/portal"
                title="Min portal"
                className="flex items-center gap-2 rounded-md px-1.5 py-1 transition-colors hover:bg-accent"
              >
                <Avatar src={avatar} name={displayName} className="h-9 w-9 text-sm" />
                <div className="hidden leading-tight sm:block">
                  <div className="max-w-[140px] truncate text-sm font-semibold">{displayName}</div>
                  <span className="rounded border px-1.5 text-[10px] text-muted-foreground">{profile?.status || "Medlem"}</span>
                </div>
              </Link>
              <button
                onClick={() => signOut()}
                title="Logga ut"
                className="rounded-md p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => signInWithDiscord()}
              className="flex items-center gap-2 rounded-md bg-[#5865F2] px-3 py-2 text-sm font-semibold text-white"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Logga in med Discord</span>
            </button>
          )}
        </header>

        <main className="flex-1 py-12">{children}</main>

        <footer className="glass mb-4 flex flex-wrap items-center justify-between gap-2 rounded-lg px-4 py-3 text-sm">
          <span className="text-muted-foreground">© 2026 {SITE_NAME}</span>
          <div className="flex gap-4">
            <a href={DISCORD_URL} className="flex items-center gap-1">
              <MessageCircle className="h-4 w-4" /> Discord
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  intro,
  back,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  back?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      {back && <div className="mb-8 text-left text-sm text-muted-foreground">{back}</div>}
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">{eyebrow}</p>
      <h1 className="text-glow mt-3 text-4xl font-bold">{title}</h1>
      {intro && <p className="mt-4 text-muted-foreground">{intro}</p>}
    </div>
  );
}

export function LoginPrompt() {
  const { user, loading, signInWithDiscord } = useAuth();
  if (loading || user) return null;
  return (
    <div className="glass mx-auto mt-10 max-w-xl rounded-lg px-4 py-5 text-center">
      <p className="text-sm text-muted-foreground">Du behöver vara inloggad med Discord för att skicka in ansökningar.</p>
      <button
        onClick={() => signInWithDiscord()}
        className="mt-4 inline-flex items-center gap-2 rounded-md bg-[#5865F2] px-5 py-2.5 text-sm font-semibold text-white"
      >
        <MessageCircle className="h-4 w-4" /> Logga in med Discord
      </button>
    </div>
  );
}

export function LoggedInBanner() {
  const { user, profile, loading } = useAuth();
  if (loading || !user) return null;
  const name = profile?.display_name || profile?.discord_username || user.user_metadata?.preferred_username || "dig";
  return (
    <div className="glass mx-auto mt-10 max-w-xl rounded-lg px-4 py-4 text-center text-sm">
      Inloggad som <strong>{name}</strong>.{" "}
      <Link to="/portal" className="underline-offset-4 hover:underline">
        Visa mina ärenden
      </Link>
    </div>
  );
}

export function Avatar({
  src,
  name,
  className = "",
}: {
  src?: string | null | undefined;
  name: string;
  className?: string;
}) {
  const [broken, setBroken] = useState(false);
  if (src && !broken) {
    return (
      <img
        src={src}
        alt=""
        referrerPolicy="no-referrer"
        onError={() => setBroken(true)}
        className={`shrink-0 rounded-full object-cover ${className}`}
      />
    );
  }
  return (
    <div className={`flex shrink-0 items-center justify-center rounded-full bg-primary font-bold text-primary-foreground ${className}`}>
      {name.slice(0, 1).toUpperCase()}
    </div>
  );
}

function NotificationBell() {
  const { items, unreadCount, isUnread, markAllRead } = useNotifications();
  const [open, setOpen] = useState(false);

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        // När man stänger listan räknas allt som läst
        if (!o && unreadCount > 0) markAllRead();
      }}
    >
      <PopoverTrigger asChild>
        <button aria-label="Notiser" className="relative rounded-md border p-2 hover:bg-accent">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-[11px] font-bold text-white">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <span className="text-sm font-semibold">Notiser</span>
          {unreadCount > 0 && (
            <button onClick={() => markAllRead()} className="text-xs text-muted-foreground hover:text-foreground">
              Markera som lästa
            </button>
          )}
        </div>
        {items.length === 0 ? (
          <p className="px-4 py-6 text-center text-sm text-muted-foreground">Inga notiser ännu.</p>
        ) : (
          <ul className="max-h-80 overflow-y-auto">
            {items.map((a) => (
              <li key={a.id}>
                <Link
                  to="/portal"
                  hash={`app-${a.id}`}
                  onClick={() => setOpen(false)}
                  className={`flex gap-3 border-b px-4 py-3 text-sm last:border-0 hover:bg-accent ${isUnread(a) ? "bg-violet-500/10" : ""}`}
                >
                  {isUnread(a) && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-red-500" />}
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{a.title}</div>
                    <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                      <span className={`rounded-full px-2 py-0.5 ${statusClass[a.status]}`}>{statusLabel[a.status]}</span>
                      {new Date(a.updated_at).toLocaleDateString("sv-SE")}
                    </div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </PopoverContent>
    </Popover>
  );
}
