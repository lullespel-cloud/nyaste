import { Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";

const tabs = [
  { to: "/staff", label: "Ansökningar", exact: true, editorOnly: false },
  { to: "/staff/dokumentation", label: "Dokumentation", exact: false, editorOnly: false },
  { to: "/staff/medlemmar", label: "Medlemmar", exact: false, editorOnly: false },
  { to: "/staff/formular", label: "Formulär", exact: false, editorOnly: true },
  { to: "/staff/regler", label: "Regler & info", exact: false, editorOnly: true },
  { to: "/staff/behorigheter", label: "Behörigheter", exact: false, editorOnly: false },
  { to: "/staff/loggar", label: "Loggar", exact: false, editorOnly: true },
] as const;

export function StaffNav() {
  const { canEdit } = useAuth();
  return (
    <nav className="glass mx-auto mt-8 flex max-w-4xl flex-wrap gap-1 rounded-lg p-1.5 text-sm font-semibold">
      {tabs
        .filter((t) => !t.editorOnly || canEdit)
        .map((t) => (
          <Link
            key={t.to}
            to={t.to}
            activeOptions={{ exact: t.exact }}
            className="rounded-md px-3 py-1.5 transition-colors hover:bg-accent"
            activeProps={{ className: "bg-accent" }}
          >
            {t.label}
          </Link>
        ))}
    </nav>
  );
}

export function NoAccess({ text = "Du måste vara inloggad och ha en staff-roll för att se den här sidan." }: { text?: string }) {
  return (
    <div className="mt-8 text-center text-sm text-muted-foreground">
      <p>{text}</p>
      <Link to="/portal" className="mt-3 inline-block underline">
        Till Min portal
      </Link>
    </div>
  );
}
