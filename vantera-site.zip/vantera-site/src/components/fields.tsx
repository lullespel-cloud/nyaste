import type { ReactNode } from "react";

export const inputCls = "w-full rounded-md border border-input bg-background px-3 py-2 text-sm";

export function Field({ label, required, help, children }: { label: string; required?: boolean | undefined; help?: string | undefined; children: ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium">
        {label}
        {required && <span className="text-red-400"> *</span>}
      </label>
      {children}
      {help && <p className="mt-1 text-xs text-muted-foreground">{help}</p>}
    </div>
  );
}
