-- =====================================================================
-- Vantera Roleplay – databas (Supabase / Postgres)
-- Kör hela filen schema.sql i Supabase → SQL Editor. Den går att köra om flera gånger.
-- Roller sätts AUTOMATISKT från Discord av edge-funktionen "sync-roles".
-- Ingen användare kan ändra sina egna roller (se policies och triggers nedan).
-- =====================================================================

-- ---------- Profiler ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  discord_id text,
  discord_username text,
  display_name text,
  avatar_url text,
  roles text[] default '{}',
  status text default 'Medlem',
  created_at timestamptz default now()
);
alter table public.profiles add column if not exists discord_roles text[] default '{}';
alter table public.profiles add column if not exists in_guild boolean;
alter table public.profiles add column if not exists roles_synced_at timestamptz;

alter table public.profiles enable row level security;

-- Städa gamla policies (den gamla lät ALLA läsa alla profiler och användare uppdatera sina egna roller)
drop policy if exists "Public profiles are viewable by everyone" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Profiles: own or staff can read" on public.profiles;

-- ---------- Hjälpfunktioner för roller ----------
-- security definer så att policies kan läsa roller utan att loopa på profiles-RLS.
create or replace function public.my_roles()
returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce((select roles from public.profiles where id = auth.uid()), '{}'::text[]);
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer set search_path = public as $$
  select public.my_roles() && array[
    'ägare','delägare','head admin','admin','head mod','mod','helper',
    'medlemskapsansvarig','krimansvarig','donationsansvarig','staff','servervakt'
  ]::text[];
$$;

-- Ägare, delägare, head admin, admin: får redigera formulär, regler, prislista och se loggar
create or replace function public.is_editor()
returns boolean
language sql stable security definer set search_path = public as $$
  select public.my_roles() && array['ägare','delägare','head admin','admin']::text[];
$$;

create policy "Profiles: own or staff can read"
  on public.profiles for select
  using (auth.uid() = id or public.is_staff());

-- ---------- Formulär (redigeras på sajten) ----------
create table if not exists public.forms (
  slug text primary key,
  category text not null check (category in ('ansokningar','serversupport')),
  title text not null,
  description text not null default '',
  fields jsonb not null default '[]',
  handler_roles text[] not null default '{}',
  enabled boolean not null default true,
  sort int not null default 100,
  updated_at timestamptz default now()
);
alter table public.forms enable row level security;

create or replace function public.can_handle_form(p_slug text)
returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_editor()
      or exists (
        select 1 from public.forms f
        where f.slug = p_slug and f.handler_roles && public.my_roles()
      );
$$;

drop policy if exists "Forms: read" on public.forms;
create policy "Forms: read" on public.forms for select using (enabled or public.is_editor());
drop policy if exists "Forms: editors insert" on public.forms;
create policy "Forms: editors insert" on public.forms for insert with check (public.is_editor());
drop policy if exists "Forms: editors update" on public.forms;
create policy "Forms: editors update" on public.forms for update using (public.is_editor()) with check (public.is_editor());
drop policy if exists "Forms: editors delete" on public.forms;
create policy "Forms: editors delete" on public.forms for delete using (public.is_editor());

-- ---------- Regler och information (redigeras på sajten) ----------
create table if not exists public.pages (
  category text not null check (category in ('regler','information')),
  slug text not null,
  title text not null,
  meta text not null default '',
  body text not null default '',
  sort int not null default 100,
  staff_only boolean not null default false,
  updated_at timestamptz default now(),
  updated_by uuid references public.profiles(id) on delete set null,
  primary key (category, slug)
);
alter table public.pages enable row level security;

drop policy if exists "Pages: read" on public.pages;
create policy "Pages: read" on public.pages for select using (not staff_only or public.is_staff());
drop policy if exists "Pages: editors insert" on public.pages;
create policy "Pages: editors insert" on public.pages for insert with check (public.is_editor());
drop policy if exists "Pages: editors update" on public.pages;
create policy "Pages: editors update" on public.pages for update using (public.is_editor()) with check (public.is_editor());
drop policy if exists "Pages: editors delete" on public.pages;
create policy "Pages: editors delete" on public.pages for delete using (public.is_editor());

create or replace function public.touch_row()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create or replace function public.touch_page()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  if auth.uid() is not null then new.updated_by := auth.uid(); end if;
  return new;
end;
$$;

drop trigger if exists forms_touch on public.forms;
create trigger forms_touch before update on public.forms for each row execute procedure public.touch_row();
drop trigger if exists pages_touch on public.pages;
create trigger pages_touch before update on public.pages for each row execute procedure public.touch_page();

-- ---------- Ansökningar ----------
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  form_slug text not null,
  title text not null,
  data jsonb default '[]',
  status text not null default 'pending' check (status in ('pending', 'approved', 'denied', 'closed')),
  staff_note text,
  handled_by uuid references public.profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.applications add column if not exists notified_new_at timestamptz;
alter table public.applications add column if not exists notified_decision_at timestamptz;
alter table public.applications enable row level security;

drop policy if exists "Users see own applications" on public.applications;
drop policy if exists "Staff can read all applications" on public.applications;
drop policy if exists "Users can insert own applications" on public.applications;
drop policy if exists "Staff can update applications" on public.applications;
drop policy if exists "Applications: own or handler can read" on public.applications;
drop policy if exists "Applications: insert own" on public.applications;
drop policy if exists "Applications: handler can update" on public.applications;

-- Man ser sina egna ansökningar + de formulärtyper ens roll får hantera (inte alla staff ser allt)
create policy "Applications: own or handler can read"
  on public.applications for select
  using (auth.uid() = user_id or public.can_handle_form(form_slug));

create policy "Applications: insert own"
  on public.applications for insert
  with check (
    auth.uid() = user_id
    and status = 'pending'
    and exists (select 1 from public.forms f where f.slug = form_slug and f.enabled)
  );

create policy "Applications: handler can update"
  on public.applications for update
  using (public.can_handle_form(form_slug))
  with check (public.can_handle_form(form_slug));

-- Staff får bara ändra status + anteckning. Svaren i ansökan går aldrig att ändra i efterhand.
create or replace function public.protect_application_update()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null then
    if new.user_id is distinct from old.user_id
       or new.form_slug is distinct from old.form_slug
       or new.category is distinct from old.category
       or new.title is distinct from old.title
       or new.data is distinct from old.data
       or new.created_at is distinct from old.created_at
       or new.notified_new_at is distinct from old.notified_new_at
       or new.notified_decision_at is distinct from old.notified_decision_at then
      raise exception 'Du kan bara ändra status och anteckning på en ansökan.';
    end if;
    if new.status is distinct from old.status then
      new.handled_by := auth.uid();
    end if;
    new.updated_at := now();
  end if;
  return new;
end;
$$;

drop trigger if exists applications_protect on public.applications;
create trigger applications_protect before update on public.applications
  for each row execute procedure public.protect_application_update();

-- ---------- Staff-dokumentation (ban / unban / donation / varning ...) ----------
create table if not exists public.staff_logs (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  target_discord text,
  target_name text,
  doc_type text not null,
  title text not null,
  body text not null,
  amount numeric,
  created_at timestamptz default now()
);
alter table public.staff_logs enable row level security;

drop policy if exists "Staff can read logs" on public.staff_logs;
create policy "Staff can read logs" on public.staff_logs for select using (public.is_staff());
drop policy if exists "Staff can insert logs" on public.staff_logs;
create policy "Staff can insert logs" on public.staff_logs for insert
  with check (auth.uid() = created_by and public.is_staff());

-- ---------- Granskningslogg (vem gjorde vad) ----------
create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  actor uuid references public.profiles(id) on delete set null,
  action text not null,
  target text,
  detail jsonb default '{}',
  created_at timestamptz default now()
);
alter table public.audit_log enable row level security;
drop policy if exists "Audit: editors read" on public.audit_log;
create policy "Audit: editors read" on public.audit_log for select using (public.is_editor());
-- Ingen insert-policy: bara triggers och service role skriver hit.

create or replace function public.audit_application()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    insert into public.audit_log (actor, action, target, detail)
    values (auth.uid(), 'ansokan_' || new.status, new.id::text,
            jsonb_build_object('formular', new.form_slug, 'titel', new.title, 'anteckning', new.staff_note));
  end if;
  return new;
end;
$$;

create or replace function public.audit_content()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  tgt text;
begin
  if tg_op = 'DELETE' then
    tgt := case when tg_table_name = 'forms' then old.slug else old.category || '/' || old.slug end;
  else
    tgt := case when tg_table_name = 'forms' then new.slug else new.category || '/' || new.slug end;
  end if;
  insert into public.audit_log (actor, action, target, detail)
  values (auth.uid(), tg_table_name || '_' || lower(tg_op), tgt, '{}'::jsonb);
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists applications_audit on public.applications;
create trigger applications_audit after update on public.applications
  for each row execute procedure public.audit_application();
drop trigger if exists forms_audit on public.forms;
create trigger forms_audit after insert or update or delete on public.forms
  for each row execute procedure public.audit_content();
drop trigger if exists pages_audit on public.pages;
create trigger pages_audit after insert or update or delete on public.pages
  for each row execute procedure public.audit_content();

-- ---------- Skapa profil automatiskt vid första Discord-inloggningen ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, discord_id, discord_username, display_name, avatar_url)
  values (
    new.id,
    new.raw_user_meta_data->>'provider_id',
    coalesce(new.raw_user_meta_data->>'preferred_username', new.raw_user_meta_data->>'full_name'),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do update set
    discord_id = excluded.discord_id,
    discord_username = excluded.discord_username,
    display_name = excluded.display_name,
    avatar_url = excluded.avatar_url;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

grant execute on function public.my_roles() to authenticated;
grant execute on function public.is_staff() to anon, authenticated;
grant execute on function public.is_editor() to anon, authenticated;
grant execute on function public.can_handle_form(text) to authenticated;
