// Gemensamma hjälpfunktioner för edge-funktionerna (Deno).
import { createClient, type SupabaseClient, type User } from "npm:@supabase/supabase-js@2";

export const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

export const env = (key: string, fallback = ""): string => Deno.env.get(key) ?? fallback;

/** JSON-hemlighet, t.ex. ROLE_MAP='{"123":["admin"]}'. Ogiltig JSON ignoreras med varning. */
export function envJson<T>(key: string, fallback: T): T {
  const raw = Deno.env.get(key);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    console.warn(`Hemligheten ${key} är inte giltig JSON – ignorerar den.`);
    return fallback;
  }
}

/** Klient som agerar som den inloggade användaren (RLS gäller). */
export function userClient(req: Request): SupabaseClient {
  return createClient(env("SUPABASE_URL"), env("SUPABASE_ANON_KEY"), {
    global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    auth: { persistSession: false },
  });
}

/** Klient med service role (kringgår RLS). Används bara på servern. */
export function adminClient(): SupabaseClient {
  return createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"), {
    auth: { persistSession: false },
  });
}

/** Verifierar JWT:n mot Supabase och returnerar användaren, annars null. */
export async function getUser(req: Request): Promise<User | null> {
  const { data, error } = await userClient(req).auth.getUser();
  if (error || !data.user) return null;
  return data.user;
}

export function discordIdOf(user: User): string | null {
  const identity = user.identities?.find((i) => i.provider === "discord");
  const id = identity?.id ?? (user.user_metadata?.provider_id as string | undefined);
  return id ? String(id) : null;
}

// ---------------- Discord ----------------
const DISCORD = "https://discord.com/api/v10";

export class DiscordError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function discord(path: string, init: RequestInit = {}, reason?: string): Promise<Response> {
  const token = env("DISCORD_BOT_TOKEN");
  if (!token) throw new DiscordError(500, "DISCORD_BOT_TOKEN saknas i Supabase-hemligheterna");
  const headers: Record<string, string> = {
    Authorization: `Bot ${token}`,
    "Content-Type": "application/json",
    "User-Agent": "VanteraPortal (https://vantera.se, 1.0)",
  };
  if (reason) headers["X-Audit-Log-Reason"] = encodeURIComponent(reason);
  return await fetch(`${DISCORD}${path}`, { ...init, headers: { ...headers, ...(init.headers ?? {}) } });
}

export const guildId = () => env("DISCORD_GUILD_ID", "1532061079675605084");
