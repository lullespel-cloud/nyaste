// Edge-funktion: application-event
//  type "created": postar en ny ansökan i rätt Discord-kanal så staff ser den direkt.
//  type "decided": DM:ar den sökande beskedet, postar i resultatkanal och ger ev. roll vid godkänd ansökan.
// Allt verifieras serverside: den som anropar måste äga ansökan (created) eller ha rätt att hantera formuläret (decided).
import { adminClient, corsHeaders, discord, env, envJson, getUser, guildId, json, userClient } from "../_shared/common.ts";

type Answer = { id?: string; label: string; value: string };

const PURPLE = 0x9b59b6;
const GREEN = 0x2ecc71;
const RED = 0xe74c3c;

function answersOf(data: unknown): Answer[] {
  if (Array.isArray(data)) return data as Answer[];
  if (data && typeof data === "object") return Object.entries(data as Record<string, string>).map(([label, value]) => ({ label, value }));
  return [];
}
const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

async function sendMessage(channelId: string, body: Record<string, unknown>) {
  const res = await discord(`/channels/${channelId}/messages`, { method: "POST", body: JSON.stringify(body) });
  if (!res.ok) console.warn("Kunde inte skicka till kanal", channelId, res.status, await res.text());
  return res.ok;
}

async function sendDm(userId: string, body: Record<string, unknown>) {
  const ch = await discord(`/users/@me/channels`, { method: "POST", body: JSON.stringify({ recipient_id: userId }) });
  if (!ch.ok) return false;
  const { id } = await ch.json() as { id: string };
  return await sendMessage(id, body);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Använd POST" }, 405);

  try {
    const user = await getUser(req);
    if (!user) return json({ error: "Inte inloggad" }, 401);

    const { type, application_id } = await req.json() as { type?: string; application_id?: string };
    if (!application_id || (type !== "created" && type !== "decided")) return json({ error: "Ogiltig förfrågan" }, 400);

    // Läs ansökan som användaren (RLS avgör att hen får se den)
    const asUser = userClient(req);
    const { data: app, error } = await asUser.from("applications").select("*").eq("id", application_id).maybeSingle();
    if (error || !app) return json({ error: "Hittar inte ansökan" }, 404);

    const admin = adminClient();
    const { data: applicant } = await admin.from("profiles").select("discord_id, discord_username").eq("id", app.user_id).maybeSingle();
    const mention = applicant?.discord_id ? `<@${applicant.discord_id}>` : (applicant?.discord_username ?? "okänd");
    const siteUrl = env("SITE_URL").replace(/\/$/, "");
    const answers = answersOf(app.data);

    if (type === "created") {
      if (app.user_id !== user.id) return json({ error: "Inte din ansökan" }, 403);
      if (app.notified_new_at) return json({ ok: true, skipped: true });

      const channels = envJson<Record<string, string>>("FORM_CHANNELS", {});
      const channelId = channels[app.form_slug] ?? env("APPLICATIONS_CHANNEL_ID");
      const pings = envJson<Record<string, string>>("PING_ROLES", {});
      const pingRole = pings[app.form_slug];

      if (channelId) {
        await sendMessage(channelId, {
          content: pingRole ? `<@&${pingRole}> ny ansökan` : undefined,
          allowed_mentions: { parse: [], roles: pingRole ? [pingRole] : [] },
          embeds: [{
            title: `📝 Ny ansökan: ${app.title}`,
            description: `Från ${mention}${siteUrl ? `\n[Öppna i staff-panelen](${siteUrl}/staff)` : ""}`,
            color: PURPLE,
            fields: answers.slice(0, 8).map((a) => ({ name: clip(a.label, 250), value: clip(a.value || "—", 400) })),
            timestamp: new Date().toISOString(),
          }],
        });
      }
      await admin.from("applications").update({ notified_new_at: new Date().toISOString() }).eq("id", app.id);
      return json({ ok: true });
    }

    // ----- decided -----
    if (app.status !== "approved" && app.status !== "denied") return json({ error: "Ansökan är inte avgjord" }, 400);
    if (app.notified_decision_at) return json({ ok: true, skipped: true });
    if (app.handled_by !== user.id) return json({ error: "Bara den som avgjorde ansökan kan skicka beskedet" }, 403);
    const { data: allowed } = await asUser.rpc("can_handle_form", { p_slug: app.form_slug });
    if (!allowed) return json({ error: "Du får inte hantera den här ansökan" }, 403);

    const approved = app.status === "approved";
    const embed = {
      title: approved ? `✅ Din ansökan är godkänd` : `❌ Din ansökan har nekats`,
      description: `**${app.title}**${app.staff_note ? `\n\n**Svar från staff:**\n${clip(app.staff_note, 1500)}` : ""}${siteUrl ? `\n\n[Se i Min portal](${siteUrl}/portal)` : ""}`,
      color: approved ? GREEN : RED,
      timestamp: new Date().toISOString(),
    };

    let dmSent = false;
    if (applicant?.discord_id) dmSent = await sendDm(applicant.discord_id, { embeds: [embed] });

    const resultsChannel = env("RESULTS_CHANNEL_ID");
    if (resultsChannel) {
      await sendMessage(resultsChannel, {
        allowed_mentions: { parse: [] },
        embeds: [{ ...embed, title: `${approved ? "✅ Godkänd" : "❌ Nekad"}: ${app.title}`, description: `Sökande: ${mention}${app.staff_note ? `\n\n${clip(app.staff_note, 1500)}` : ""}` }],
      });
    }

    // Ge roll automatiskt vid godkänd ansökan, t.ex. {"medlemskap":"ROLL_ID","kriminell":"1566816770457739274"}
    let roleGiven = false;
    const approveRoles = envJson<Record<string, string>>("APPROVE_ROLES", {});
    const roleId = approveRoles[app.form_slug];
    if (approved && roleId && applicant?.discord_id) {
      const r = await discord(`/guilds/${guildId()}/members/${applicant.discord_id}/roles/${roleId}`, { method: "PUT" }, `Godkänd ansökan på sajten: ${app.title}`);
      roleGiven = r.ok;
      if (!r.ok) console.warn("Kunde inte ge roll", r.status, await r.text());
    }

    await admin.from("applications").update({ notified_decision_at: new Date().toISOString() }).eq("id", app.id);
    return json({ ok: true, dmSent, roleGiven });
  } catch (e) {
    console.error(e);
    return json({ error: e instanceof Error ? e.message : "Okänt fel" }, 500);
  }
});
