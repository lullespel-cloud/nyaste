// Edge-funktion: sync-roles
// Hämtar användarens RIKTIGA Discord-roller från servern (via botten) och sätter behörigheterna på sajten.
// Användaren kan inte påverka resultatet: Discord-id kommer från den verifierade inloggningen och
// rollerna hämtas serverside med bot-token. Hemligheter ligger bara i Supabase, aldrig i webbläsaren.
import { adminClient, corsHeaders, discord, discordIdOf, env, envJson, getUser, guildId, json } from "../_shared/common.ts";

// Discord-roll-ID  →  roller på sajten. Standardvärdena kommer från botens config.js.
// Lägg till/ändra med hemligheten ROLE_MAP_EXTRA (slås ihop) eller ROLE_MAP (ersätter allt).
const DEFAULT_ROLE_MAP: Record<string, string[]> = {
  "1566816725880668271": ["ägare"], //            Ägare
  "1566816730137764020": ["delägare"], //         Ledning
  "1566816726790832178": ["head admin"], //       Lead Admin
  "1566816727814242374": ["admin"], //            Admin
  "1566816732478181507": ["admin"], //            Utvecklare (samma som botten ger i staff-discorden)
  "1566816731496845442": ["head mod"], //         Lead Mod
  "1566816733065388133": ["mod"], //              Mod
  "1566816735292817468": ["helper"], //           Helper
  "1566816747284205578": ["krimansvarig"], //     Kriminell ansvarig
  "1566816770457739274": ["kriminell"], //        Kriminell
  "1566816734365745152": ["staff"], //            Staff (allmän)
};

// Staff-roller i prioritetsordning – styr vilken "status" som visas i portalen.
const STAFF_ORDER = [
  "ägare", "delägare", "head admin", "admin", "head mod", "mod", "helper",
  "krimansvarig", "medlemskapsansvarig", "donationsansvarig", "servervakt", "staff",
];
const STATUS_LABEL: Record<string, string> = {
  "ägare": "Ägare", "delägare": "Delägare", "head admin": "Head Admin", admin: "Admin",
  "head mod": "Head Mod", mod: "Mod", helper: "Helper", krimansvarig: "Krimansvarig",
  medlemskapsansvarig: "Medlemskapsansvarig", donationsansvarig: "Donationsansvarig",
  servervakt: "Servervakt", staff: "Staff",
};

function buildRoleMap(): Record<string, string[]> {
  const full = envJson<Record<string, string[]> | null>("ROLE_MAP", null);
  if (full) return full;
  return { ...DEFAULT_ROLE_MAP, ...envJson<Record<string, string[]>>("ROLE_MAP_EXTRA", {}) };
}

function discordAvatar(member: { user?: { id: string; avatar?: string | null }; avatar?: string | null }): string | null {
  const u = member.user;
  if (!u?.avatar) return null;
  return `https://cdn.discordapp.com/avatars/${u.id}/${u.avatar}.png?size=128`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Använd POST" }, 405);

  try {
    const user = await getUser(req);
    if (!user) return json({ error: "Inte inloggad" }, 401);

    const discordId = discordIdOf(user);
    if (!discordId) return json({ error: "Kontot saknar Discord-koppling. Logga in med Discord." }, 400);

    const res = await discord(`/guilds/${guildId()}/members/${discordId}`);
    const admin = adminClient();

    const meta = user.user_metadata ?? {};
    const baseProfile = {
      id: user.id,
      discord_id: discordId,
      discord_username: (meta.preferred_username ?? meta.user_name ?? meta.full_name ?? null) as string | null,
      display_name: (meta.full_name ?? meta.name ?? null) as string | null,
      avatar_url: (meta.avatar_url ?? meta.picture ?? null) as string | null,
    };

    // Inte med i servern: rensa alla roller (t.ex. om någon lämnat eller blivit kickad)
    if (res.status === 404) {
      const { error } = await admin.from("profiles").upsert({
        ...baseProfile, roles: [], discord_roles: [], in_guild: false,
        status: "Ej i Discord-servern", roles_synced_at: new Date().toISOString(),
      });
      if (error) throw new Error(error.message);
      return json({ ok: true, in_guild: false, roles: [], status: "Ej i Discord-servern" });
    }

    // Vid Discord-fel (rate limit, 5xx) behåller vi de gamla rollerna istället för att nollställa dem.
    if (!res.ok) {
      console.error("Discord svarade", res.status, await res.text());
      return json({ error: "Discord svarade inte just nu. Försök igen om en stund." }, 502);
    }

    const member = await res.json() as {
      roles: string[];
      nick?: string | null;
      user?: { id: string; username?: string; global_name?: string | null; avatar?: string | null };
    };

    const roleMap = buildRoleMap();
    const siteRoles = new Set<string>();
    for (const rid of member.roles) for (const r of roleMap[rid] ?? []) siteRoles.add(r.toLowerCase());

    // Valfri roll som krävs för "medlem" (t.ex. Whitelistad). Utan den räcker det att vara med i servern.
    const memberRoleId = env("MEMBER_ROLE_ID");
    if (!memberRoleId || member.roles.includes(memberRoleId)) siteRoles.add("medlem");

    const roles = [...siteRoles];
    const top = STAFF_ORDER.find((r) => siteRoles.has(r));
    const status = top ? STATUS_LABEL[top] : siteRoles.has("kriminell") ? "Kriminell" : siteRoles.has("medlem") ? "Medlem" : "Gäst";

    const { error } = await admin.from("profiles").upsert({
      ...baseProfile,
      discord_username: member.user?.username ?? baseProfile.discord_username,
      display_name: member.nick ?? member.user?.global_name ?? baseProfile.display_name,
      avatar_url: discordAvatar(member) ?? baseProfile.avatar_url,
      roles,
      discord_roles: member.roles,
      in_guild: true,
      status,
      roles_synced_at: new Date().toISOString(),
    });
    if (error) throw new Error(error.message);

    return json({ ok: true, in_guild: true, roles, status });
  } catch (e) {
    console.error(e);
    return json({ error: e instanceof Error ? e.message : "Okänt fel" }, 500);
  }
});
