-- =====================================================================
-- Vantera Roleplay – databas (Supabase / Postgres)
-- Kör hela filen schema.sql i Supabase → SQL Editor. Den går att köra om flera gånger.
-- Roller sätts AUTOMATISKT från Discord av edge-funktionen "sync-roles".
-- Ingen användare kan ändra sina egna roller (se policies och triggers nedan).
-- =====================================================================

-- ---------- Profiler ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  discord_id text,
  discord_username text,
  display_name text,
  avatar_url text,
  roles text[] default '{}',
  status text default 'Medlem',
  created_at timestamptz default now()
);
alter table public.profiles add column if not exists discord_roles text[] default '{}';
alter table public.profiles add column if not exists in_guild boolean;
alter table public.profiles add column if not exists roles_synced_at timestamptz;

alter table public.profiles enable row level security;

-- Städa gamla policies (den gamla lät ALLA läsa alla profiler och användare uppdatera sina egna roller)
drop policy if exists "Public profiles are viewable by everyone" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Profiles: own or staff can read" on public.profiles;

-- ---------- Hjälpfunktioner för roller ----------
-- security definer så att policies kan läsa roller utan att loopa på profiles-RLS.
create or replace function public.my_roles()
returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce((select roles from public.profiles where id = auth.uid()), '{}'::text[]);
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer set search_path = public as $$
  select public.my_roles() && array[
    'ägare','delägare','head admin','admin','head mod','mod','helper',
    'medlemskapsansvarig','krimansvarig','donationsansvarig','staff','servervakt'
  ]::text[];
$$;

-- Ägare, delägare, head admin, admin: får redigera formulär, regler, prislista och se loggar
create or replace function public.is_editor()
returns boolean
language sql stable security definer set search_path = public as $$
  select public.my_roles() && array['ägare','delägare','head admin','admin']::text[];
$$;

create policy "Profiles: own or staff can read"
  on public.profiles for select
  using (auth.uid() = id or public.is_staff());

-- ---------- Formulär (redigeras på sajten) ----------
create table if not exists public.forms (
  slug text primary key,
  category text not null check (category in ('ansokningar','serversupport')),
  title text not null,
  description text not null default '',
  fields jsonb not null default '[]',
  handler_roles text[] not null default '{}',
  enabled boolean not null default true,
  sort int not null default 100,
  updated_at timestamptz default now()
);
alter table public.forms enable row level security;

create or replace function public.can_handle_form(p_slug text)
returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_editor()
      or exists (
        select 1 from public.forms f
        where f.slug = p_slug and f.handler_roles && public.my_roles()
      );
$$;

drop policy if exists "Forms: read" on public.forms;
create policy "Forms: read" on public.forms for select using (enabled or public.is_editor());
drop policy if exists "Forms: editors insert" on public.forms;
create policy "Forms: editors insert" on public.forms for insert with check (public.is_editor());
drop policy if exists "Forms: editors update" on public.forms;
create policy "Forms: editors update" on public.forms for update using (public.is_editor()) with check (public.is_editor());
drop policy if exists "Forms: editors delete" on public.forms;
create policy "Forms: editors delete" on public.forms for delete using (public.is_editor());

-- ---------- Regler och information (redigeras på sajten) ----------
create table if not exists public.pages (
  category text not null check (category in ('regler','information')),
  slug text not null,
  title text not null,
  meta text not null default '',
  body text not null default '',
  sort int not null default 100,
  staff_only boolean not null default false,
  updated_at timestamptz default now(),
  updated_by uuid references public.profiles(id) on delete set null,
  primary key (category, slug)
);
alter table public.pages enable row level security;

drop policy if exists "Pages: read" on public.pages;
create policy "Pages: read" on public.pages for select using (not staff_only or public.is_staff());
drop policy if exists "Pages: editors insert" on public.pages;
create policy "Pages: editors insert" on public.pages for insert with check (public.is_editor());
drop policy if exists "Pages: editors update" on public.pages;
create policy "Pages: editors update" on public.pages for update using (public.is_editor()) with check (public.is_editor());
drop policy if exists "Pages: editors delete" on public.pages;
create policy "Pages: editors delete" on public.pages for delete using (public.is_editor());

create or replace function public.touch_row()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create or replace function public.touch_page()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  if auth.uid() is not null then new.updated_by := auth.uid(); end if;
  return new;
end;
$$;

drop trigger if exists forms_touch on public.forms;
create trigger forms_touch before update on public.forms for each row execute procedure public.touch_row();
drop trigger if exists pages_touch on public.pages;
create trigger pages_touch before update on public.pages for each row execute procedure public.touch_page();

-- ---------- Ansökningar ----------
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  form_slug text not null,
  title text not null,
  data jsonb default '[]',
  status text not null default 'pending' check (status in ('pending', 'approved', 'denied', 'closed')),
  staff_note text,
  handled_by uuid references public.profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.applications add column if not exists notified_new_at timestamptz;
alter table public.applications add column if not exists notified_decision_at timestamptz;
alter table public.applications enable row level security;

drop policy if exists "Users see own applications" on public.applications;
drop policy if exists "Staff can read all applications" on public.applications;
drop policy if exists "Users can insert own applications" on public.applications;
drop policy if exists "Staff can update applications" on public.applications;
drop policy if exists "Applications: own or handler can read" on public.applications;
drop policy if exists "Applications: insert own" on public.applications;
drop policy if exists "Applications: handler can update" on public.applications;

-- Man ser sina egna ansökningar + de formulärtyper ens roll får hantera (inte alla staff ser allt)
create policy "Applications: own or handler can read"
  on public.applications for select
  using (auth.uid() = user_id or public.can_handle_form(form_slug));

create policy "Applications: insert own"
  on public.applications for insert
  with check (
    auth.uid() = user_id
    and status = 'pending'
    and exists (select 1 from public.forms f where f.slug = form_slug and f.enabled)
  );

create policy "Applications: handler can update"
  on public.applications for update
  using (public.can_handle_form(form_slug))
  with check (public.can_handle_form(form_slug));

-- Staff får bara ändra status + anteckning. Svaren i ansökan går aldrig att ändra i efterhand.
create or replace function public.protect_application_update()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null then
    if new.user_id is distinct from old.user_id
       or new.form_slug is distinct from old.form_slug
       or new.category is distinct from old.category
       or new.title is distinct from old.title
       or new.data is distinct from old.data
       or new.created_at is distinct from old.created_at
       or new.notified_new_at is distinct from old.notified_new_at
       or new.notified_decision_at is distinct from old.notified_decision_at then
      raise exception 'Du kan bara ändra status och anteckning på en ansökan.';
    end if;
    if new.status is distinct from old.status then
      new.handled_by := auth.uid();
    end if;
    new.updated_at := now();
  end if;
  return new;
end;
$$;

drop trigger if exists applications_protect on public.applications;
create trigger applications_protect before update on public.applications
  for each row execute procedure public.protect_application_update();

-- ---------- Staff-dokumentation (ban / unban / donation / varning ...) ----------
create table if not exists public.staff_logs (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  target_discord text,
  target_name text,
  doc_type text not null,
  title text not null,
  body text not null,
  amount numeric,
  created_at timestamptz default now()
);
alter table public.staff_logs enable row level security;

drop policy if exists "Staff can read logs" on public.staff_logs;
create policy "Staff can read logs" on public.staff_logs for select using (public.is_staff());
drop policy if exists "Staff can insert logs" on public.staff_logs;
create policy "Staff can insert logs" on public.staff_logs for insert
  with check (auth.uid() = created_by and public.is_staff());

-- ---------- Granskningslogg (vem gjorde vad) ----------
create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  actor uuid references public.profiles(id) on delete set null,
  action text not null,
  target text,
  detail jsonb default '{}',
  created_at timestamptz default now()
);
alter table public.audit_log enable row level security;
drop policy if exists "Audit: editors read" on public.audit_log;
create policy "Audit: editors read" on public.audit_log for select using (public.is_editor());
-- Ingen insert-policy: bara triggers och service role skriver hit.

create or replace function public.audit_application()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    insert into public.audit_log (actor, action, target, detail)
    values (auth.uid(), 'ansokan_' || new.status, new.id::text,
            jsonb_build_object('formular', new.form_slug, 'titel', new.title, 'anteckning', new.staff_note));
  end if;
  return new;
end;
$$;

create or replace function public.audit_content()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  tgt text;
begin
  if tg_op = 'DELETE' then
    tgt := case when tg_table_name = 'forms' then old.slug else old.category || '/' || old.slug end;
  else
    tgt := case when tg_table_name = 'forms' then new.slug else new.category || '/' || new.slug end;
  end if;
  insert into public.audit_log (actor, action, target, detail)
  values (auth.uid(), tg_table_name || '_' || lower(tg_op), tgt, '{}'::jsonb);
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists applications_audit on public.applications;
create trigger applications_audit after update on public.applications
  for each row execute procedure public.audit_application();
drop trigger if exists forms_audit on public.forms;
create trigger forms_audit after insert or update or delete on public.forms
  for each row execute procedure public.audit_content();
drop trigger if exists pages_audit on public.pages;
create trigger pages_audit after insert or update or delete on public.pages
  for each row execute procedure public.audit_content();

-- ---------- Skapa profil automatiskt vid första Discord-inloggningen ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, discord_id, discord_username, display_name, avatar_url)
  values (
    new.id,
    new.raw_user_meta_data->>'provider_id',
    coalesce(new.raw_user_meta_data->>'preferred_username', new.raw_user_meta_data->>'full_name'),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do update set
    discord_id = excluded.discord_id,
    discord_username = excluded.discord_username,
    display_name = excluded.display_name,
    avatar_url = excluded.avatar_url;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

grant execute on function public.my_roles() to authenticated;
grant execute on function public.is_staff() to anon, authenticated;
grant execute on function public.is_editor() to anon, authenticated;
grant execute on function public.can_handle_form(text) to authenticated;

-- ===================== STARTDATA (genereras av scripts/gen-seed.mjs) =====================

-- Formulär. Redigeras sedan på sajten under Staff → Formulär.
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('medlemskap', 'ansokningar', 'Medlemskapsansökan', 'Ansök om att få spela på Vantera Roleplay. Läs reglerna först.', '[{"id":"alder","label":"Hur gammal är du?","type":"number","required":true},{"id":"steam","label":"Steam-namn eller Steam-ID","required":true},{"id":"karaktar","label":"Karaktärsnamn","required":true},{"id":"bakgrund","label":"Kort bakgrund för din karaktär","type":"textarea","required":true},{"id":"erfarenhet","label":"Tidigare erfarenhet av rollspel","type":"textarea","required":true},{"id":"regler","label":"Har du läst och förstått reglerna?","type":"select","options":["Ja","Nej"],"required":true},{"id":"rdmvdm","label":"Förklara med egna ord vad RDM och VDM är","type":"textarea","required":true},{"id":"varfor","label":"Varför vill du spela på Vantera?","type":"textarea","required":true}]'::jsonb, array['medlemskapsansvarig']::text[], true, 10)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('kriminell', 'ansokningar', 'Kriminellansökan', 'Ansök om kriminell roll. Berätta om din karaktär och hur du skapar rollspel för andra.', '[{"id":"karaktar","label":"Karaktärsnamn","required":true},{"id":"bakgrund","label":"Beskriv karaktärens bakgrund och hur den hamnade i kriminalitet","type":"textarea","required":true},{"id":"mal","label":"Vilka mål har karaktären?","type":"textarea","required":true},{"id":"erfarenhet","label":"Tidigare erfarenhet av kriminella roller","type":"textarea"},{"id":"rollspel","label":"Hur skapar du bra rollspel för motparten, även när du förlorar?","type":"textarea","required":true},{"id":"regler","label":"Vilka krimregler tycker du är viktigast och varför?","type":"textarea","required":true},{"id":"scenario","label":"Scenario: Du blir omringad av polisen och har inga vapen kvar. Vad gör du?","type":"textarea","required":true}]'::jsonb, array['krimansvarig']::text[], true, 20)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('servervakt', 'ansokningar', 'Servervaktsansökan', 'Ansök om att bli servervakt och hjälpa till med ordningen på servern.', '[{"id":"alder","label":"Hur gammal är du?","type":"number","required":true},{"id":"erfarenhet","label":"Tidigare erfarenhet av liknande uppdrag","type":"textarea"},{"id":"motivation","label":"Varför vill du bli servervakt?","type":"textarea","required":true},{"id":"aktivitet","label":"Hur många timmar i veckan kan du vara aktiv?","required":true},{"id":"scenario1","label":"Scenario: En spelare skriker i röstchatten och hotar andra. Vad gör du?","type":"textarea","required":true},{"id":"scenario2","label":"Scenario: Två spelare är oense om en situation var RP eller inte. Hur löser du det?","type":"textarea","required":true}]'::jsonb, array['head mod','mod','servervakt']::text[], true, 30)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('staff', 'ansokningar', 'Staffansökan', 'Att vara staff på Vantera innebär att följa reglerna, samarbeta med teamet och vara aktiv.', '[{"id":"roll","label":"Vilken roll söker du?","type":"select","options":["Helper","Mod","Admin"],"required":true},{"id":"alder","label":"Hur gammal är du?","type":"number","required":true},{"id":"erfarenhet","label":"Tidigare erfarenhet som staff eller moderator","type":"textarea"},{"id":"motivation","label":"Varför vill du bli staff?","type":"textarea","required":true},{"id":"aktivitet","label":"Hur aktiv kan du vara, och vilka tider?","type":"textarea","required":true},{"id":"scenario","label":"Scenario: En vän till dig bryter mot reglerna. Hur hanterar du det?","type":"textarea","required":true}]'::jsonb, array['head mod','mod']::text[], true, 40)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('jobb', 'ansokningar', 'Jobbansökan', 'Ansök om att bli chef eller anställd inom ett yrke eller företag.', '[{"id":"jobb","label":"Vilket jobb eller företag?","type":"select","options":["Polis","Sjukvård","Mekaniker","Taxi","Annat (skriv nedan)"],"required":true},{"id":"karaktar","label":"Karaktärsnamn","required":true},{"id":"erfarenhet","label":"Tidigare erfarenhet av yrket i rollspel","type":"textarea"},{"id":"motivation","label":"Varför just dig?","type":"textarea","required":true},{"id":"annat","label":"Om du valde Annat, vilket jobb?"}]'::jsonb, array['head mod','mod']::text[], true, 50)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('medlemskapsansvarig', 'ansokningar', 'Ansökan om medlemskapsansvarig', 'Ansök om rollen medlemskapsansvarig, som hanterar medlemsansökningar.', '[{"id":"motivation","label":"Varför vill du ha den här rollen?","type":"textarea","required":true},{"id":"aktivitet","label":"Hur aktiv kan du vara?","type":"textarea","required":true}]'::jsonb, '{}'::text[], true, 60)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('banoverklagan', 'serversupport', 'Banöverklagan', 'Be om en ny bedömning av din avstängning. Bara du och staff kan läsa ärendet.', '[{"id":"banid","label":"Ban-ID (om du har det)"},{"id":"datum","label":"Ungefär när blev du bannad?","required":true},{"id":"anledning","label":"Vilken anledning fick du?","type":"textarea","required":true},{"id":"forklaring","label":"Varför bör banen omprövas?","type":"textarea","required":true},{"id":"bevis","label":"Bevis eller länkar","type":"textarea"},{"id":"tidigare","label":"Har du överklagat samma ban tidigare?","type":"select","options":["Ja","Nej"],"required":true}]'::jsonb, array['helper','mod','head mod','medlemskapsansvarig','krimansvarig','donationsansvarig','staff','servervakt']::text[], true, 10)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('staffanmalan', 'serversupport', 'Staffanmälan', 'Anmäl missbruk av staff. Beskriv händelsen tydligt och bifoga länkar till bevis. Läses bara av ledningen.', '[{"id":"vem","label":"Vilken staff gäller det?","required":true},{"id":"beskrivning","label":"Beskriv händelsen","type":"textarea","required":true},{"id":"bevis","label":"Bevis eller länkar","type":"textarea"}]'::jsonb, '{}'::text[], true, 20)
on conflict (slug) do nothing;
insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values ('servervaktanmalan', 'serversupport', 'Servervaktanmälan', 'Anmäl problem eller situationer som servervaktsansvarig bör ta del av.', '[{"id":"beskrivning","label":"Beskriv problemet","type":"textarea","required":true},{"id":"bevis","label":"Bevis eller länkar","type":"textarea"}]'::jsonb, array['head mod','mod','servervakt']::text[], true, 30)
on conflict (slug) do nothing;

-- Regler och information. Redigeras sedan på sajten under Staff → Regler & info.
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'community', 'Communityregler', 'Regler · Gäller alla medlemmar', $body$> Genom att spela eller vara medlem hos oss godkänner du alla regler på den här sidan. Okunskap om reglerna ursäktar inte regelbrott.

## Respekt och uppförande
1. Visa respekt mot alla spelare och all staff, i spelet, i Discord och på sajten.
2. Hat, hot, trakasserier, rasism, sexism och diskriminering tolereras inte och leder till avstängning.
3. Personangrepp och påhopp utanför rollspelet är förbjudet. Konflikter hanteras i ett ärende, inte i chatten.
4. Du får aldrig dela andra spelares personuppgifter, bilder eller privata konversationer utan tillstånd.

## Konton och identitet
1. Du ansvarar för ditt konto. Att låna ut eller sälja ditt konto är förbjudet.
2. Att utge sig för att vara staff eller ledning är förbjudet.
3. Ett konto per person om inte ledningen godkänt annat.

## Fusk och missbruk
1. Fusk, hacks, modmenyer och utnyttjande av buggar är förbjudet. Hittar du en bugg ska du rapportera den.
2. Att sälja eller byta spelföremål, pengar eller konton mot riktiga pengar utanför serverns officiella donationer är förbjudet.

## Straff
Straffet beror på allvarlighetsgrad och tidigare ärenden. Staff kan ge varning, tillfällig avstängning eller permanent avstängning.
Du kan överklaga en avstängning via **Banöverklagan** under Ansökningar → Serversupport.$body$, 10, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'discord', 'Discordregler', 'Regler · Gäller i alla våra Discord-servrar', $body$## Allmänt
1. Följ Discords användarvillkor och riktlinjer.
2. Skriv i rätt kanal och håll dig till ämnet.
3. Spam, överdrivna pingar och upprepade meddelanden är förbjudet.
4. Reklam för andra servrar eller communities samt inbjudningslänkar är förbjudet utan tillstånd.
5. Ditt visningsnamn ska vara läsbart och får inte vara kränkande eller imitera staff.

## Innehåll
1. Pornografiskt, grafiskt våldsamt eller olagligt innehåll är förbjudet.
2. Politik och religion hålls utanför våra kanaler om det leder till bråk.
3. Röstchatten ska hållas fri från störande ljud, soundboards och skrik.

## Staff och ärenden
1. Diskutera inte staffbeslut offentligt. Använd ett ärende eller en banöverklagan.
2. Följ alltid instruktioner från staff i Discord. Ifrågasätt i efterhand via ärende.
3. Pinga inte staff i onödan.$body$, 20, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'grundregler', 'Grundregler för rollspel', 'Regler · Gäller alla i spelet', $body$> Rollspel handlar om att skapa en bra upplevelse tillsammans. Spela för att andra ska ha roligt, inte för att vinna.

## Grundbegrepp
- **RP (rollspel):** Du agerar som din karaktär och håller dig i rollen.
- **FailRP:** Att agera orealistiskt eller bryta mot det som är rimligt i verkligheten.
- **RDM (Random Deathmatch):** Att döda eller skada någon utan rollspelsgrund.
- **VDM (Vehicle Deathmatch):** Att köra på någon med fordon utan rollspelsgrund.
- **Metagaming:** Att använda information du fått utanför rollspelet (Discord, stream, röstchatt) i spelet.
- **Powergaming:** Att tvinga fram ett utfall eller göra saker som inte ger andra en chans att reagera.
- **NLR (New Life Rule):** Efter att din karaktär dött glömmer du hur det gick till och återvänder inte till platsen under din avstängning från händelsen.

## Regler
1. RDM och VDM är förbjudet. Allt våld ska ha en tydlig rollspelsorsak.
2. Du ska alltid värdera ditt liv. Är du under hot eller har vapen riktat mot dig agerar du rädd och följer instruktioner (Fear RP).
3. Metagaming och powergaming är förbjudet.
4. Du får inte lämna spelet (combat logga) under pågående rollspel. Behöver du lämna ska du meddela de du spelar med.
5. Sluta aldrig med rollspelet för att det går dåligt för din karaktär. Att förlora är en del av berättelsen.
6. Använd /me och /do så att andra förstår vad din karaktär gör.
7. Ljudtrick, glitchar och exploits som ger fördel är förbjudet.
8. Rollspel i safezones (sjukhus, polisstation, spawn m.fl.) ska hållas lugnt. Våld och brott där är förbjudet.
9. Följ staffs instruktioner direkt i spelet. Ifrågasätt efteråt via ärende.

## Utanför rollen (OOC)
1. Prata inte utanför rollen i röstchatten i spelet. Använd /ooc sparsamt.
2. Hotar någon dig utanför rollspelet, kontakta staff direkt.$body$, 30, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'karaktar', 'Karaktärsregler', 'Regler · Karaktärer och namn', $body$## Skapa karaktär
1. Karaktärsnamnet ska vara realistiskt. Kända personer, fiktiva figurer och skämtnamn är förbjudna.
2. Din karaktär ska ha en trovärdig bakgrund, personlighet och mål.
3. Karaktärens ålder ska vara minst 18 år.
4. Du får inte ha släktskap med eller kopiera en annan spelares karaktär utan överenskommelse.

## Spela karaktären
1. Du måste spela din karaktär konsekvent och realistiskt, även med dess begränsningar.
2. Karaktären får inte ha övermänskliga egenskaper eller kunskaper.
3. Karaktärsbyte eller ny karaktär ska ske genom att tidigare karaktär avslutas på ett rimligt sätt i rollspelet.
4. Du får inte använda kunskap från en annan av dina karaktärer.

## Namn och utseende
1. Kläder, ped och utseende ska passa rollspelet och inte vara kränkande.
2. Egna pedar och specialmodeller beställs enligt prislistan och godkänns av ledningen.$body$, 40, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'kriminell', 'Kriminella regler', 'Regler · Gäller dig med kriminell roll', $body$> Kriminalitet ska skapa spännande rollspel för alla inblandade. Du behöver en godkänd kriminellansökan för att begå brott.

## Grundkrav
1. Du måste ha kriminell roll för att begå planerade brott som rån, kidnappning och försäljning av olagliga varor.
2. Alla brott ska ha en rollspelsgrund och ett rimligt motiv.
3. Varje brott ska ge motparten en chans att reagera och spela med.

## Brott och motparter
1. Du får inte våldsamt ta ut någon som inte gett dig anledning. Spela upp hot och förhandling först.
2. Gisslan ska behandlas med rollspelsmässig hänsyn. Överdrivet våld eller tortyr som inte är rollspel är förbjudet.
3. Du får inte råna samma person flera gånger i rad utan ny anledning.
4. Nybörjare och personer utan kriminell roll får inte utsättas för grova brott utan rollspelsgrund.

## Polisen och rättsprocess
1. Du måste följa polisens instruktioner under gripande, förhör och straff om det finns rollspelsgrund.
2. Flykt från polisen ska spelas realistiskt. Orimliga flyktförsök och glitchar är förbjudna.
3. Du får inte fritas utan rollspel.

## Krimvarningar
Brott mot dessa regler ger krimvarning. Den fjärde varningen innebär att din kriminella roll dras in. Frågor om varningar tas via ärende till krimansvarig.$body$, 50, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'gang', 'Gängregler', 'Regler · För gäng och organisationer', $body$## Bilda och driva ett gäng
1. Ett gäng måste ha en tydlig bakgrund, identitet och ledare, och godkännas av ledningen.
2. Gängets namn, färger och symboler får inte vara kränkande eller kopiera andra communities.
3. Alla medlemmar måste ha kriminell roll.

## Samspel mellan gäng
1. Krig mellan gäng måste ha en tydlig rollspelsgrund och godkännas av ledningen vid större konflikter.
2. Gängkonflikter ska inte dra in oskyldiga spelare.
3. Du får inte organisera dig mot andra spelare för att trakassera dem utanför rollspelet.

## Gänghus och fordon
1. Gänghus och egna fordon beställs enligt prislistan och godkänns av ledningen.
2. Missbruk av gänghus, till exempel för att undvika rollspel, kan leda till att det tas bort.

## Inaktivitet
Ett gäng som varit inaktivt en längre tid kan tas bort och dess tillgångar återgå till servern.$body$, 60, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'jobb', 'Jobbregler', 'Regler · Polis, sjukvård, mekaniker m.fl.', $body$## Allmänt
1. Du som har ett jobb måste spela jobbet seriöst och professionellt.
2. Missbruk av jobbets befogenheter är förbjudet.
3. Du får inte vara aktiv i flera yrkesgrenar samtidigt utan dubbelarbetare-tillstånd.

## Polis
1. Du får inte använda våld utan tydlig grund. Följ proportionalitet och hota före våld.
2. Information från utredningar får inte användas för personlig vinning.
3. Du får inte gripa någon utan skälig misstanke.

## Sjukvård
1. Du ska behandla alla patienter lika, oavsett vem de är.
2. Du får inte kräva betalning som inte står i regelverket.

## Chefer och ägare
1. Chefer ansvarar för att deras anställda följer reglerna.
2. Anställda kan sparkas av chefen med rollspelsgrund.$body$, 70, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'fordon', 'Fordonsregler', 'Regler · Körning och fordon', $body$## Körning
1. Du ska köra realistiskt. Stunts, hopp och flygande bilar är förbjudet utan rollspelsgrund.
2. VDM är förbjudet.
3. Parkera fordon på rimliga platser. Att blockera trafik, entréer eller spawn med syfte att störa är förbjudet.

## Egna fordon
1. Importfordon och egna modeller beställs och godkänns enligt prislistan.
2. Fordonsfilen får inte vara större än den storlek som anges i prislistan.
3. Fordon som orsakar prestandaproblem kan tas bort.

## Stöld och handel
1. Fordon får bara stjälas med rollspelsgrund. Att stjäla ur polis- och ambulansbilar kräver särskilt tillstånd.
2. Att sälja eller byta fordon mot riktiga pengar utanför servern är förbjudet.$body$, 80, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('regler', 'staff', 'Staffregler', 'Regler · Endast synlig för staff', $body$> Den här sidan syns bara för inloggad staff.

## Uppförande
1. Du representerar Vantera. Var lugn, saklig och professionell mot alla.
2. Du får aldrig missbruka dina befogenheter, till exempel för att ge dig själv eller vänner fördelar.
3. Du får inte dela intern information, ärenden eller loggar med spelare.

## Beslut och bestraffning
1. Dokumentera alla varningar, bans och kickar på sajten under Staff → Dokumentation.
2. Ge den mildaste lämpliga åtgärden först. Grova regelbrott kan leda direkt till ban.
3. Banna aldrig någon i affekt. Är du osäker, fråga en högre staff.
4. Du får inte bestraffa någon du har en pågående konflikt med. Lämna över ärendet.

## Ärenden och ansökningar
1. Hantera bara de ansökningar och ärenden din roll ansvarar för.
2. Skriv alltid en kort motivering när du godkänner eller nekar en ansökan.
3. Banöverklaganden bedöms rättvist och med hänsyn till tidigare ärenden.

## Aktivitet
1. Staff förväntas vara aktiv. Meddela ledningen vid längre frånvaro.
2. Inaktiv staff kan förlora sin roll.$body$, 90, true)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('information', 'kopvillkor', 'Köpvillkor', 'Information · Donationer och köp', $body$Innan du gör en donation eller ett köp hos oss ber vi dig läsa igenom köpvillkoren noggrant. De innehåller viktig information om dina rättigheter, våra policyer kring betalning och återbetalning.

Genom att fortsätta med en donation eller ett köp förutsätter vi att du har läst, förstått och godkänt villkoren i sin helhet.

Har du frågor eller behöver förtydliganden är du alltid välkommen att kontakta oss genom en ledningsticket innan du slutför din transaktion.$body$, 10, false)
on conflict (category, slug) do nothing;
insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values ('information', 'prislista', 'Prislista', 'Information · Donationer och tillval', $body$> Betalning: Swish och PayPal. Läs köpvillkoren före köp. Priser och villkor kan uppdateras.

## Specifika föremål
Föremål / tjänst | Pris
Kriminell roll | 150 kr
Kriminell roll (om du blivit av med den) | 200 kr
Kriminell roll (fuskökning) | 500 kr
Krim case | 100 kr / st
Privatinköp | 1 500 kr
Dubbelarbetare | 300 kr

## Bilrelaterade priser
Föremål / tjänst | Pris
Ej inlagt importfordon | 500 kr (max 30 MB)
Inlagt importfordon | Se importbilar-kanalen
Patent till fordon | 200 kr
Importöverföring | 200 kr
Inlagt billjud | 150 kr
Ej inlagt billjud | 300 kr
Bilfirma bil | 150 kr

## Pedrelaterade priser
Föremål / tjänst | Pris
PED | 500 kr (max 30 MB)
PED-byte (en som finns in-game) | 150 kr
PED-byte (ny modell) | 200 kr (max 30 MB)
Extra plats för delad PED | 100 kr
Specialgångstil | 200 kr

## Gängrelaterade priser
Föremål / tjänst | Pris
Gäng | Kolla lediga gäng
Lagning | 200 kr
Inlagt icke-importfordon till gäng | 100 kr
Byte av färg på fordon till gäng | 100 kr
Namnbyte på gäng | 100 kr
Importerat gänghus (ej in-game) | 750 kr
Byte av gänghus (in-game) | 150 kr
Helikopter till gäng | 800 kr
Båtar till gäng | 250 kr

## Specifika inköp till gäng i FiveM
Föremål / tjänst | Pris i spelet | Pris i SEK
AK-47 | 500 000 kr | 400 kr
SCAR-H | 500 000 kr | 400 kr
UZI | 500 000 kr | 500 kr
TAURUS | 200 000 kr | 300 kr
RUST AK | 550 000 kr | 800 kr
GLOCK 19 | 350 000 kr | 300 kr
AUG | 500 000 kr | 350 kr
P90 | 500 000 kr | 350 kr
GLOCK 17 | 600 000 kr | 550 kr
DEAGLE | 500 000 kr | 400 kr
MP45 | 500 000 kr | 500 kr
GLOCK 18C | 550 000 kr | 350 kr
G17C | 500 000 kr | 500 kr
MP7 | 550 000 kr | 550 kr
DRACO | 500 000 kr | 500 kr
SPECIALINKÖP (GTA-VAPEN, IN-GAME) | 500 000 kr | 600 kr
SPECIALINKÖP (EJ IN-GAME) | 600 000 kr | 900 kr
SPECIALINKÖP (FINNS IN-GAME) | 550 000 kr | Beroende på vapen

## Tillägg och tillbehör
Föremål / tjänst | Pris i spelet | Pris i SEK
LJUDDÄMPARE | 75 000 kr | 200 kr
GREPP | 65 000 kr | 200 kr
DRUM MAG / EXTENDED CLIP | 75 000 kr | 200 kr
SKOTTLÅDA | 20 000 kr | 150 kr$body$, 20, false)
on conflict (category, slug) do nothing;
