// Genererar supabase/schema.sql = supabase/schema.base.sql + startdata (formulär + sidor).
// Kör: node scripts/gen-seed.mjs   (kräver Node 22+)
import { readFileSync, writeFileSync } from "node:fs";
import { DEFAULT_FORMS } from "../src/lib/default-forms.ts";
import { DEFAULT_PAGES } from "../src/lib/default-pages.ts";

const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
const arr = (a) => (a.length ? `array[${a.map(q).join(",")}]::text[]` : "'{}'::text[]");

let out = readFileSync(new URL("../supabase/schema.base.sql", import.meta.url), "utf8");
out += "\n-- ===================== STARTDATA (genereras av scripts/gen-seed.mjs) =====================\n\n";
out += "-- Formulär. Redigeras sedan på sajten under Staff → Formulär.\n";
for (const f of DEFAULT_FORMS) {
  out += `insert into public.forms (slug, category, title, description, fields, handler_roles, enabled, sort)
values (${q(f.slug)}, ${q(f.category)}, ${q(f.title)}, ${q(f.description)}, ${q(JSON.stringify(f.fields))}::jsonb, ${arr(f.handler_roles)}, ${f.enabled}, ${f.sort})
on conflict (slug) do nothing;\n`;
}
out += "\n-- Regler och information. Redigeras sedan på sajten under Staff → Regler & info.\n";
for (const p of DEFAULT_PAGES) {
  out += `insert into public.pages (category, slug, title, meta, body, sort, staff_only)
values (${q(p.category)}, ${q(p.slug)}, ${q(p.title)}, ${q(p.meta)}, $body$${p.body}$body$, ${p.sort}, ${p.staff_only})
on conflict (category, slug) do nothing;\n`;
}
writeFileSync(new URL("../supabase/schema.sql", import.meta.url), out);
console.log("Skrev supabase/schema.sql");
