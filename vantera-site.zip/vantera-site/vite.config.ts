import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import netlify from "@netlify/vite-plugin-tanstack-start";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Gratis hosting på Netlify (se SETUP.md). Ändra inte ordningen på pluginerna.
export default defineConfig({
  plugins: [tsConfigPaths(), tanstackStart(), netlify(), viteReact(), tailwindcss()],
});
