# Vantera Roleplay – installation (Discord-roller, ansökningar, regler, staff-panel)

Allt kör gratis: **Supabase** (databas, inloggning, Edge Functions) + **Netlify** (hosting av sajten).

## Så hänger det ihop

```
Discord-inloggning ──► Supabase Auth ──► sajten (React)
                                         │  efter inloggning
                                         ▼
                         Edge Function "sync-roles"
                         (bot-token ligger bara här)
                                         │ frågar Discord vilka roller personen har
                                         ▼
                         profiles.roles i databasen ──► styr vad personen får se/göra
```

* Behörigheter styrs av **riktiga Discord-roller**. Du behöver inte längre skriva SQL per person.
* Ingen kan ge sig själv roller via webbläsaren: databasen (RLS) tillåter det inte, och rollerna hämtas på servern.
* Ändrar du en roll i Discord slår det igenom inom ~5 min när personen har sajten öppen, eller direkt när hen trycker **Uppdatera roller** i Min portal.
* Nya ansökningar postas i en Discord-kanal. När staff godkänner/nekar får den sökande ett **DM**, och rollen kan delas ut automatiskt.

## Roller

| Discord-roll (ID från botens config.js) | Sajtroll | Hanterar | Redigerar regler/formulär |
|---|---|---|---|
| Ägare | ägare | Allt | Ja |
| Ledning | delägare | Allt | Ja |
| Lead Admin | head admin | Allt | Ja |
| Admin, Utvecklare | admin | Allt | Ja |
| Lead Mod | head mod | Staff, servervakt, jobb, banöverklagan | Nej |
| Mod | mod | Staff, servervakt, jobb, banöverklagan | Nej |
| Helper | helper | Banöverklagan | Nej |
| Kriminell ansvarig | krimansvarig | Bara kriminellansökningar + banöverklagan | Nej |
| Medlemskapsansvarig* | medlemskapsansvarig | Bara medlemskap + banöverklagan | Nej |
| Donationsansvarig* | donationsansvarig | Banöverklagan + dokumentera donationer | Nej |
| Servervakt* | servervakt | Servervakt-ansökan/anmälan | Nej |

\* Dessa tre finns inte i botens `config.js`. Lägg in deras roll-ID i `ROLE_MAP_EXTRA` (steg 5). Gissa gärna fel i tabellen – det är bara att ändra: vilka som hanterar vad ställer du in på sajten under **Staff → Formulär**, och vilken Discord-roll som ger vilken sajtroll står i `supabase/functions/sync-roles/index.ts` eller i hemligheterna.

> Antaganden jag gjort: **Ledning = Delägare** och **Utvecklare = Admin** (samma som PortalBot gör i staff-discorden). Ändra i `ROLE_MAP_EXTRA`/`ROLE_MAP` om det inte stämmer.

---

## 1. Supabase

1. Skapa ett gratis projekt på https://supabase.com.
2. **Project Settings → API**: kopiera *Project URL* och *anon public key*.
3. **SQL Editor**: klistra in hela `supabase/schema.sql` och kör. Då skapas tabeller, säkerhetsregler, **standardformulär** och **standardregler/prislista**. Filen går att köra om.

## 2. Discord-inloggning

1. https://discord.com/developers/applications → din applikation (samma som boten går bra) → **OAuth2**: kopiera *Client ID* och *Client Secret*.
2. Samma sida → **Redirects**: lägg till `https://DITT-PROJEKT.supabase.co/auth/v1/callback`.
3. Supabase → **Authentication → Providers → Discord**: slå på, klistra in Client ID/Secret.
4. Supabase → **Authentication → URL Configuration**: *Site URL* = din Netlify-adress. Under *Redirect URLs* lägg till `https://DIN-SAJT.netlify.app/portal` och `http://localhost:5173/portal`.

## 3. Edge Functions (rollsynk + Discord-notiser)

Kräver Node. Kör i projektmappen:

```bash
npx supabase login
npx supabase link --project-ref DITT-PROJEKT-REF        # står i Supabase-URL:en
cp supabase/secrets.example.env supabase/secrets.env     # fyll i filen (steg 4)
npx supabase secrets set --env-file supabase/secrets.env
npx supabase functions deploy sync-roles
npx supabase functions deploy application-event
```

## 4. Hemligheter (supabase/secrets.env)

Öppna `supabase/secrets.env` och fyll i. Det viktigaste:

* `DISCORD_BOT_TOKEN` – samma bot som PortalBot (Developer Portal → Bot → Reset Token). **Dela aldrig token** och lägg den aldrig i `.env`, GitHub eller webbläsaren. Har den läckt: återställ den.
* `DISCORD_GUILD_ID` – huvudservern (förifylld).
* `SITE_URL` – sajtens adress.
* `APPLICATIONS_CHANNEL_ID` – kanalen där nya ansökningar ska dyka upp.

Boten måste vara med i huvudservern och ha **Server Members Intent** på (den har det redan). För att dela ut roller vid godkänd ansökan (`APPROVE_ROLES`) behöver den **Manage Roles** och ligga över rollen.

## 5. Roller som saknas i botens config

I Discord: Inställningar → Avancerat → slå på **Utvecklarläge**. Serverinställningar → Roller → högerklicka rollen → **Kopiera roll-ID**. Lägg in i `ROLE_MAP_EXTRA` i `secrets.env`, kör `secrets set` igen. Nästa rollsynk (max 5 min) tar emot det.

## 6. Publicera gratis på Netlify

1. Lägg projektmappen på GitHub (privat går bra). Se till att `.env` och `supabase/secrets.env` inte följer med (de är ignorerade).
2. https://app.netlify.com → *Add new site → Import from Git*. Build command `npm run build`, publish directory `dist/client` (står redan i `netlify.toml`).
3. *Site configuration → Environment variables*: lägg in `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` och `VITE_DISCORD_URL`.
4. Deploya. Gå tillbaka till steg 2.4 och 4 och sätt rätt adress i *Site URL* / `SITE_URL`.

Lokalt: `cp .env.example .env`, fyll i, `npm install`, `npm run dev` (http://localhost:5173).

## 7. Testa

1. Logga in med Discord → **Min portal** ska visa dina roller från Discord.
2. Har du en staff-roll syns **Staff** i menyn.
3. Skicka en testansökan → den ska dyka upp i Discord-kanalen och i Staff → Ansökningar.
4. Godkänn den → du får ett DM, och rollen delas ut om du satt `APPROVE_ROLES`.

## Redigera innehåll (utan kod)

* **Staff → Formulär** (Ägare/Delägare/Head Admin/Admin): lägg till/ändra/stäng formulär, frågor (text, lång text, val, nummer) och vilka roller som får hantera dem.
* **Staff → Regler & info**: redigera alla regelkapitel, köpvillkor och prislistan med förhandsvisning. Ändringar syns direkt. Staffreglerna syns bara för staff.
* **Staff → Loggar**: vem som godkänt/nekat och vem som ändrat regler/formulär.

Reglerna jag lagt in är ett **utkast** skrivet från er struktur. Gå igenom dem (åldrar, straff, siffror, gängkrav) och justera så de stämmer med hur ni vill ha det.

## Säkerhet (kort)

* Roller sätts bara av servern. Användare kan inte uppdatera sin egen profil/roll, och staff kan inte ändra svaren i en ansökan (bara status + svar).
* Man ser bara ärenden man själv skickat eller som ens roll får hantera. Banöverklaganden: alla staff. Staffanmälan: bara ledningen.
* Ändringar du gör med SQL direkt på `profiles.roles` skrivs över vid nästa rollsynk. Ändra rollen i Discord istället.
